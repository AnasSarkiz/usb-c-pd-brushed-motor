import { distance } from "./geometry"
import type { RoutedSegment } from "./types"

/** Zero-length same-layer segments must not conceal the next real copper turn. */
export function fanoutSegmentsHaveValidTurns(
  segments: readonly RoutedSegment[],
): boolean {
  const epsilon = 1e-7
  let previousVector:
    | { dx: number; dy: number; length: number; layer: string }
    | undefined
  for (const [index, segment] of segments.entries()) {
    const previousSegment = segments[index - 1]
    if (previousSegment) {
      if (distance(previousSegment.end, segment.start) > epsilon) return false
      if (previousSegment.layer !== segment.layer) previousVector = undefined
    }
    const dx = segment.end.x - segment.start.x
    const dy = segment.end.y - segment.start.y
    const length = Math.hypot(dx, dy)
    if (
      Math.min(
        Math.abs(dx),
        Math.abs(dy),
        Math.abs(Math.abs(dx) - Math.abs(dy)),
      ) > epsilon
    )
      return false
    if (length < epsilon) continue
    if (
      previousVector?.layer === segment.layer &&
      (previousVector.dx * dx + previousVector.dy * dy) /
        (previousVector.length * length) <
        Math.SQRT1_2 - epsilon
    )
      return false
    previousVector = { dx, dy, length, layer: segment.layer }
  }
  return true
}
