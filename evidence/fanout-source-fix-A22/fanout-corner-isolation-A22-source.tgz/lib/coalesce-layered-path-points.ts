import { distance } from "./geometry"
import type { LayeredPathPoint } from "./normalize-layered-path"

/** Final-path cleanup in board-world mm; retain exact terminals and layer changes. */
export function coalesceLayeredPathPoints(
  points: readonly LayeredPathPoint[],
): LayeredPathPoint[] {
  const coalesced: LayeredPathPoint[] = []
  for (const [pointIndex, point] of points.entries()) {
    const previous = coalesced.at(-1)
    if (previous?.z === point.z && distance(previous, point) < 1e-7) {
      if (pointIndex === points.length - 1)
        coalesced[coalesced.length - 1] = point
      continue
    }
    coalesced.push(point)
  }
  return coalesced
}
