import { getSvgFromGraphicsObject } from "graphics-debug"
import { FanoutSolver } from "../lib/fanout-solver"

const fixture = Bun.argv[2]
if (!fixture || !/^[a-z0-9-]+$/.test(fixture))
  throw new Error(
    "Supply a fixture basename containing letters, digits and hyphens",
  )
const input: {
  simpleRouteJson: ConstructorParameters<typeof FanoutSolver>[0]
  solverOptions: ConstructorParameters<typeof FanoutSolver>[1]
} = await Bun.file(
  new URL(`../tests/fixtures/${fixture}.json`, import.meta.url),
).json()
const solver = new FanoutSolver(input.simpleRouteJson, input.solverOptions)
const maximumDurationMs = Number(Bun.argv[3])
if (!Number.isFinite(maximumDurationMs) || maximumDurationMs <= 0)
  throw new Error("Supply a positive profiling duration in milliseconds")
const deadline = performance.now() + maximumDurationMs
while (!solver.solved && !solver.failed) {
  for (
    let stepIndex = 0;
    stepIndex < 1000 && !solver.solved && !solver.failed;
    stepIndex++
  )
    solver.step()
  // Batch native steps so event-loop scheduling does not dominate the profile.
  await Bun.sleep(0)
  if (performance.now() >= deadline) {
    console.error(
      "Diagnostic deadline expired; no completed solution is accepted",
    )
    process.exit(2)
  }
}
if (!solver.solved) throw new Error(String(solver.error))
const outputPath = `../../evidence/fanout-source-fix-A22/${fixture}-final-stage-native`
await Bun.write(`${outputPath}.json`, JSON.stringify(solver.getOutput()))
await Bun.write(
  `${outputPath}.svg`,
  getSvgFromGraphicsObject(solver.visualize()),
)
console.log(`Solved ${fixture}; retained unmodified native output and image`)
