import { expect, test } from "bun:test"
import { getSvgFromGraphicsObject } from "graphics-debug"
import { buildOutputSimpleRouteJson } from "lib/build-output"
import { prepareFanoutBuses } from "lib/prepare-buses"
import { routeReservedViaBusesSteps } from "lib/route-reserved-via-buses"
import { prepareSourceOriginReservations } from "lib/route-source-origin-buses"
import { validateRoutedCopperDrc } from "lib/validate-routed-copper-drc"
import type { SimpleRouteJsonWithViaDrillRules } from "lib/via-drills-are-clear"
import { visualizeSimpleRouteJson } from "lib/visualize-simple-route-json"
import { expectSvgSnapshotWithActual } from "./fixtures/expect-svg-snapshot-with-actual"

test("source-origin finalization retains an accepted plane without reserving its drill twice", async () => {
  const bounds = { minX: -3, maxX: 3, minY: -3, maxY: 3 }
  const rules = {
    traceWidth: 0.1,
    clearance: 0.1,
    viaDiameter: 0.3,
    viaHoleDiameter: 0.15,
  }
  const layerNames = ["top", "inner1", "inner2", "bottom"]
  const sources = [-0.5, 0.5, 1.5].map((y) => ({ x: -2, y }))
  const srj: SimpleRouteJsonWithViaDrillRules = {
    bounds,
    layerCount: 4,
    minTraceWidth: 0.1,
    minViaHoleEdgeToViaHoleEdgeClearance: 0.15,
    connections: sources.map((source, index) => ({
      name: `N${index}`,
      pointsToConnect: [
        {
          ...source,
          layer: "top",
          pointId: `P${index}`,
          pcb_port_id: `P${index}`,
        },
        ...(index < 2 ? [{ x: 3, y: source.y, layer: "inner1" }] : []),
      ],
    })),
    obstacles: sources.map((center, index) => ({
      type: "rect",
      center,
      width: 0.3,
      height: 0.3,
      componentId: "U1",
      obstacleId: `P${index}`,
      layers: ["top"],
      connectedTo: [`N${index}`, `P${index}`],
    })),
  }
  const allBuses = prepareFanoutBuses(srj, {
    sharedBoundary: bounds,
    buses: [
      {
        busId: "signals",
        sourceComponentId: "U1",
        connectionNames: ["N0", "N1"],
        direction: "right",
        preferredExit: "right",
        allowedLayers: ["inner1"],
      },
      {
        busId: "plane",
        sourceComponentId: "U1",
        connectionNames: ["N2"],
        direction: "right",
        termination: { type: "plane", layer: "inner2" },
      },
    ],
  })
  const source = prepareSourceOriginReservations({
    ...rules,
    srj,
    buses: allBuses,
    layerNames,
  })!
  expect(source).not.toBeNull()
  const bus = allBuses.find((bus) => bus.busId === "signals")!
  const acceptedPlans = source.sourcePlans.filter(
    (plan) => plan.termination.type === "plane",
  )
  expect(acceptedPlans).toHaveLength(1)
  const before = JSON.stringify({ srj, source, allBuses, acceptedPlans })
  const steps = routeReservedViaBusesSteps({
    ...rules,
    srj,
    allBuses,
    buses: [bus],
    targetLayer: "inner1",
    transitLayers: ["inner1"],
    layerNames,
    ...source,
    acceptedPlans,
    routeFromSourcePads: true,
    sourceLayerTravelCost: 2,
    maximumIterations: 300_000,
    terminals: bus.connections.map((connection) => ({
      connection,
      viaPoint: source.fixedViaPointsByConnectionIndex.get(
        connection.connectionIndex,
      )!,
      exitPoint: { x: 3, y: connection.targetPoint.y },
    })),
  })
  let next = steps.next()
  while (!next.done) next = steps.next()
  expect(next.value).not.toBeNull()
  expect(next.value).toHaveLength(2)
  expect(JSON.stringify({ srj, source, allBuses, acceptedPlans })).toBe(before)
  const outputSrj = buildOutputSimpleRouteJson({
    inputSrj: srj,
    plans: [...acceptedPlans, ...next.value!],
    layerNames,
  })
  expect(
    validateRoutedCopperDrc({
      inputSrj: srj,
      routedSrj: outputSrj,
      clearance: 0.1,
      allowBlindAndBuriedVias: false,
    }),
  ).toMatchObject({
    valid: true,
    checkedTraceCount: 3,
    checkedViaCount: 3,
    issues: [],
  })
  await expectSvgSnapshotWithActual(
    getSvgFromGraphicsObject(visualizeSimpleRouteJson(outputSrj)),
    import.meta.path,
  )
})
