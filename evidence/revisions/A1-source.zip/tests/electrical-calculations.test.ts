import { describe, expect, test } from "bun:test"
import {
  chooseMotorContract,
  motorInputCurrentA,
  pwmTiming,
  regulatedMotorVoltageV,
} from "../scripts/electrical-calculations"

describe("PD power qualification", () => {
  test("rejects insufficient chargers including native 12 V", () => {
    for (const capability of [
      { voltageV: 5, currentA: 3 },
      { voltageV: 9, currentA: 3 },
      { voltageV: 12, currentA: 3 },
      { voltageV: 15, currentA: 2 },
      { voltageV: 20, currentA: 2.25 },
    ]) {
      expect(chooseMotorContract([capability])).toBeNull()
    }
  })
  test("prefers qualified 20 V and falls back to qualified 15 V", () => {
    expect(
      chooseMotorContract([
        { voltageV: 15, currentA: 3 },
        { voltageV: 20, currentA: 3 },
      ]),
    ).toEqual({ voltageV: 20, currentA: 3 })
    expect(chooseMotorContract([{ voltageV: 15, currentA: 3 }])).toEqual({
      voltageV: 15,
      currentA: 3,
    })
  })
  test("worst assumed 12 V continuous input fits minimum eFuse limit", () => {
    const minimumLimitA = ((18_000 / 6_800) * 0.9) / 1.01
    expect(
      motorInputCurrentA({
        motorVoltageV: 12,
        motorCurrentA: 2,
        contractVoltageV: 15,
      }),
    ).toBeLessThan(minimumLimitA)
    // Record the real limitation instead of asserting a fictitious peak margin.
    expect(
      motorInputCurrentA({
        motorVoltageV: 12,
        motorCurrentA: 2.4,
        contractVoltageV: 15,
      }),
    ).toBeGreaterThan(minimumLimitA)
    expect(
      motorInputCurrentA({
        motorVoltageV: 12,
        motorCurrentA: 2.4,
        contractVoltageV: 20,
      }),
    ).toBeLessThan(minimumLimitA)
  })
})

describe("10 k potentiometer and selected motor rail", () => {
  test("regulates all three modes within 0.1 percent nominal", () => {
    for (const [branchOhms, voltageV] of [
      [undefined, 5],
      [21_000, 9],
      [12_000, 12],
    ] as const) {
      expect(
        Math.abs(regulatedMotorVoltageV(branchOhms) - voltageV) / voltageV,
      ).toBeLessThan(0.0011)
    }
  })
  test("PWM has useful monotonically increasing range with finite end times", () => {
    let previousDuty = 0
    for (let step = 0; step <= 100; step++) {
      const timing = pwmTiming({ fraction: step / 100 })
      expect(timing.frequencyHz).toBeGreaterThan(19_000)
      expect(timing.frequencyHz).toBeLessThan(22_000)
      expect(timing.dutyFraction).toBeGreaterThan(previousDuty)
      previousDuty = timing.dutyFraction
    }
    expect(pwmTiming({ fraction: 0 }).dutyFraction).toBeLessThan(0.04)
    expect(pwmTiming({ fraction: 1 }).dutyFraction).toBeGreaterThan(0.96)
  })
})
