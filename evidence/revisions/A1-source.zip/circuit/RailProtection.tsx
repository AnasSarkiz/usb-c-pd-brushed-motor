import { A_0603WAF3242T5E } from "../imports/A_0603WAF3242T5E"
import { CC0603KRX7R9BB104 } from "../imports/CC0603KRX7R9BB104"
import { A_0603WAF1001T5E } from "../imports/A_0603WAF1001T5E"
import { A_0603WAF1004T5E } from "../imports/A_0603WAF1004T5E"
import { A_0603WAF5622T5E } from "../imports/A_0603WAF5622T5E"
import { A_0603WAF2432T5E } from "../imports/A_0603WAF2432T5E"
import { TL431AIDBZR } from "../imports/TL431AIDBZR"
import { A_0603WAF1003T5E } from "../imports/A_0603WAF1003T5E"
import { FRC0603F8062TS } from "../imports/FRC0603F8062TS"
import { LM393DR } from "../imports/LM393DR"
import { CRCW060310K0FKEA } from "../imports/CRCW060310K0FKEA"
import { B5819W_SL } from "../imports/B5819W_SL"

export function RailProtection() {
  return (
    <>
      {/* 2.495 V reference */}
      <TL431AIDBZR
        name="U8"
        schSheetName="protection"
        schX={-11.0}
        schY={8}
        connections={{
          CATHODE: "net.VREF2V5",
          REF: "net.VREF2V5",
          ANODE: "net.GND",
        }}
      />
      {/* Reference bias about 2.5 mA */}
      <A_0603WAF1001T5E
        name="R31"
        schSheetName="protection"
        schX={-5.5}
        schY={8}
        schRotation={-90.0}
        connections={{
          pin1: "net.VDD5",
          pin2: "net.VREF2V5",
        }}
      />
      {/* Undervoltage motor disable and independent overvoltage dump */}
      <LM393DR
        name="U9"
        schSheetName="protection"
        schX={0.0}
        schY={8}
        connections={{
          "1OUT": "net.MOTOR_READY",
          "1IN_NEG": "net.UV_REF",
          "1IN_POS": "net.MOTOR_FB",
          GND: "net.GND",
          "2IN_POS": "net.OV_REF",
          "2IN_NEG": "net.OV_SENSE",
          "2OUT": "net.OV_ACTIVE_N",
          VCC: "net.VDD5",
        }}
      />
      {/* 0.727 V undervoltage reference top */}
      <A_0603WAF2432T5E
        name="R32"
        schSheetName="protection"
        schX={5.5}
        schY={8}
        schRotation={-90.0}
        connections={{
          pin1: "net.VREF2V5",
          pin2: "net.UV_REF",
        }}
      />
      {/* Undervoltage reference bottom */}
      <CRCW060310K0FKEA
        name="R33"
        schSheetName="protection"
        schX={11.0}
        schY={8}
        schRotation={-90.0}
        connections={{
          pin1: "net.UV_REF",
          pin2: "net.GND",
        }}
      />
      {/* Motor readiness open-drain pull-up */}
      <A_0603WAF1001T5E
        name="R34"
        schSheetName="protection"
        schX={-11.0}
        schY={4}
        schRotation={-90.0}
        connections={{
          pin1: "net.VCC3V3",
          pin2: "net.MOTOR_READY",
        }}
      />
      {/* Input-PG interlock on motor readiness */}
      <B5819W_SL
        name="D8"
        schSheetName="protection"
        schX={-5.5}
        schY={4}
        connections={{
          anode: "net.MOTOR_READY",
          cathode: "net.INPUT_PG",
        }}
      />
      {/* Separate overvoltage divider upper */}
      <A_0603WAF1003T5E
        name="R35"
        schSheetName="protection"
        schX={0.0}
        schY={4}
        schRotation={-90.0}
        connections={{
          pin1: "net.VM",
          pin2: "net.OV_SENSE",
        }}
      />
      {/* Default 5 V clamp divider lower */}
      <FRC0603F8062TS
        name="R36"
        schSheetName="protection"
        schX={5.5}
        schY={4}
        schRotation={-90.0}
        connections={{
          pin1: "net.OV_SENSE",
          pin2: "net.GND",
        }}
      />
      {/* 9 V clamp divider branch */}
      <A_0603WAF5622T5E
        name="R37"
        schSheetName="protection"
        schX={11.0}
        schY={4}
        connections={{
          pin1: "net.OV_SENSE",
          pin2: "net.OV_SELECT_9",
        }}
      />
      {/* 12 V clamp divider branch */}
      <A_0603WAF3242T5E
        name="R38"
        schSheetName="protection"
        schX={-11.0}
        schY={0}
        connections={{
          pin1: "net.OV_SENSE",
          pin2: "net.OV_SELECT_12",
        }}
      />
      {/* OV hysteresis reference isolation */}
      <CRCW060310K0FKEA
        name="R39"
        schSheetName="protection"
        schX={-5.5}
        schY={0}
        schRotation={-90.0}
        connections={{
          pin1: "net.VREF2V5",
          pin2: "net.OV_REF",
        }}
      />
      {/* OV hysteresis feedback */}
      <A_0603WAF1004T5E
        name="R40"
        schSheetName="protection"
        schX={0.0}
        schY={0}
        connections={{
          pin1: "net.OV_ACTIVE_N",
          pin2: "net.OV_REF",
        }}
      />
      {/* Monitor local bypass */}
      <CC0603KRX7R9BB104
        name="C25"
        schSheetName="protection"
        schX={5.5}
        schY={0}
        schRotation={-90.0}
        connections={{
          pin1: "net.VDD5",
          pin2: "net.GND",
        }}
      />
    </>
  )
}
