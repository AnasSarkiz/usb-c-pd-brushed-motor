import { CC0603KRX7R9BB104 } from "../imports/CC0603KRX7R9BB104"
import { A_0603WAF1001T5E } from "../imports/A_0603WAF1001T5E"
import { A_0603WAF3300T5E } from "../imports/A_0603WAF3300T5E"
import { SS_23D03_G080 } from "../imports/SS_23D03_G080"
import { A_19_217_G7C_AN1P2_6T } from "../imports/A_19_217_G7C_AN1P2_6T"
import { GRM1885C1H562JA01D } from "../imports/GRM1885C1H562JA01D"
import { PTV09A_4015F_B103 } from "../imports/PTV09A_4015F_B103"
import { A_0603B103K500NT } from "../imports/A_0603B103K500NT"
import { TLC555CDR } from "../imports/TLC555CDR"
import { CRCW060310K0FKEA } from "../imports/CRCW060310K0FKEA"
import { B5819W_SL } from "../imports/B5819W_SL"
import { SN74LVC2G08DCUR } from "../imports/SN74LVC2G08DCUR"

export function PwmControls() {
  return (
    <>
      {/* Hardware potentiometer PWM */}
      <TLC555CDR
        name="U6"
        schSheetName="controls"
        schX={-11.0}
        schY={8}
        connections={{
          GND: "net.GND",
          TRIG: "net.TIMING",
          OUT: "net.PWM",
          RESET: "net.MOTOR_READY",
          CONT: "net.TIMER_CONT",
          THRES: "net.TIMING",
          DISCH: "net.WIPER",
          VDD: "net.VCC3V3",
        }}
      />
      {/* Bourns vertical 10 k linear speed pot */}
      <PTV09A_4015F_B103
        name="RV1"
        schSheetName="controls"
        schX={-5.5}
        schY={8}
        connections={{
          pin1: "net.POT_CHARGE",
          pin2: "net.WIPER",
          pin3: "net.POT_DISCHARGE",
          pin4: "net.GND",
          pin5: "net.GND",
        }}
      />
      {/* Charge end resistance */}
      <A_0603WAF3300T5E
        name="R25"
        schSheetName="controls"
        schX={0.0}
        schY={8}
        schRotation={-90.0}
        connections={{
          pin1: "net.VCC3V3",
          pin2: "net.WIPER",
        }}
      />
      {/* Steer charging through one pot segment */}
      <B5819W_SL
        name="D6"
        schSheetName="controls"
        schX={5.5}
        schY={8}
        connections={{
          anode: "net.POT_CHARGE",
          cathode: "net.TIMING",
        }}
      />
      {/* Steer discharging through opposite segment */}
      <B5819W_SL
        name="D7"
        schSheetName="controls"
        schX={11.0}
        schY={8}
        connections={{
          anode: "net.TIMING",
          cathode: "net.DISCHARGE_END",
        }}
      />
      {/* Discharge end resistance */}
      <A_0603WAF3300T5E
        name="R26"
        schSheetName="controls"
        schX={-11.0}
        schY={4}
        connections={{
          pin1: "net.DISCHARGE_END",
          pin2: "net.POT_DISCHARGE",
        }}
      />
      {/* 5.6 nF C0G PWM timing */}
      <GRM1885C1H562JA01D
        name="C21"
        schSheetName="controls"
        schX={-5.5}
        schY={4}
        schRotation={-90.0}
        connections={{
          pin1: "net.TIMING",
          pin2: "net.GND",
        }}
      />
      {/* Timer threshold bypass */}
      <A_0603B103K500NT
        name="C22"
        schSheetName="controls"
        schX={0.0}
        schY={4}
        schRotation={-90.0}
        connections={{
          pin1: "net.TIMER_CONT",
          pin2: "net.GND",
        }}
      />
      {/* Timer local bypass */}
      <CC0603KRX7R9BB104
        name="C23"
        schSheetName="controls"
        schX={5.5}
        schY={4}
        schRotation={-90.0}
        connections={{
          pin1: "net.VCC3V3",
          pin2: "net.GND",
        }}
      />
      {/* REV/OFF/FWD command: unused middle contact */}
      <SS_23D03_G080
        name="SW1"
        schSheetName="controls"
        schX={11.0}
        schY={4}
        noConnect={["pin2", "pin5", "pin6", "pin7", "pin8"]}
        connections={{
          pin1: "net.REV_CMD",
          pin3: "net.VCC3V3",
          pin4: "net.FWD_CMD",
          pin9: "net.GND",
          pin10: "net.GND",
        }}
      />
      {/* Direction default low */}
      <CRCW060310K0FKEA
        name="R27"
        schSheetName="controls"
        schX={-11.0}
        schY={0}
        schRotation={-90.0}
        connections={{
          pin1: "net.REV_CMD",
          pin2: "net.GND",
        }}
      />
      {/* Direction default low */}
      <CRCW060310K0FKEA
        name="R28"
        schSheetName="controls"
        schX={-5.5}
        schY={0}
        schRotation={-90.0}
        connections={{
          pin1: "net.FWD_CMD",
          pin2: "net.GND",
        }}
      />
      {/* PWM direction gating; OFF drives both inputs low */}
      <SN74LVC2G08DCUR
        name="U7"
        schSheetName="controls"
        schX={0.0}
        schY={0}
        connections={{
          "1A": "net.PWM",
          "1B": "net.FWD_CMD",
          "2Y": "net.IN2",
          GND: "net.GND",
          "2A": "net.PWM",
          "2B": "net.REV_CMD",
          "1Y": "net.IN1",
          VCC: "net.VCC3V3",
        }}
      />
      {/* Logic local bypass */}
      <CC0603KRX7R9BB104
        name="C24"
        schSheetName="controls"
        schX={5.5}
        schY={0}
        schRotation={-90.0}
        connections={{
          pin1: "net.VCC3V3",
          pin2: "net.GND",
        }}
      />
      {/* LED current limit */}
      <A_0603WAF1001T5E
        name="R29"
        schSheetName="controls"
        schX={11.0}
        schY={0}
        connections={{
          pin1: "net.FWD_CMD",
          pin2: "net.R29_LED",
        }}
      />
      {/* LED current limit */}
      <A_0603WAF1001T5E
        name="R30"
        schSheetName="controls"
        schX={-11.0}
        schY={-4}
        connections={{
          pin1: "net.REV_CMD",
          pin2: "net.R30_LED",
        }}
      />
      {/* Forward command indicator */}
      <A_19_217_G7C_AN1P2_6T
        name="LED2"
        schSheetName="controls"
        schX={-5.5}
        schY={-4}
        schRotation={-90.0}
        connections={{
          anode: "net.R29_LED",
          cathode: "net.GND",
        }}
      />
      {/* Reverse command indicator */}
      <A_19_217_G7C_AN1P2_6T
        name="LED3"
        schSheetName="controls"
        schX={0.0}
        schY={-4}
        schRotation={-90.0}
        connections={{
          anode: "net.R30_LED",
          cathode: "net.GND",
        }}
      />
    </>
  )
}
