import { UsbInput } from "./circuit/UsbInput"
import { InputProtection } from "./circuit/InputProtection"
import { MotorSupply } from "./circuit/MotorSupply"
import { PwmControls } from "./circuit/PwmControls"
import { RailProtection } from "./circuit/RailProtection"
import { EnergyDump } from "./circuit/EnergyDump"
import { MotorBridge } from "./circuit/MotorBridge"

export default function UsbCPdBrushedMotorController() {
  return (
    <board
      width="65mm"
      height="50mm"
      thickness="1.6mm"
      layers={2}
      routingDisabled
    >
      <net name="GND" isGroundNet />
      <net name="VBUS" isPowerNet nominalTraceWidth="2mm" />
      <net name="VDD5" isPowerNet />
      <net name="VCC3V3" isPowerNet />
      <net name="EFUSE_IN" isPowerNet nominalTraceWidth="2mm" />
      <net name="VIN_BUCK" isPowerNet nominalTraceWidth="2mm" />
      <net name="VM" isPowerNet nominalTraceWidth="2mm" />
      <net name="MOTOR_P" nominalTraceWidth="2mm" />
      <net name="MOTOR_N" nominalTraceWidth="2mm" />
      <schematicsheet
        name="usb"
        displayName="USB-C PD and quiet supplies · A1"
        sheetSize="A4"
        sheetIndex={1}
      >
        <schematictext
          text="A1 PROTOTYPE | USB-C PD and quiet supplies · A1 | 1/7"
          schX={0}
          schY={10.2}
          fontSize={0.3}
        />
        <schematictext
          text="DRAFT — schematic validation incomplete — routing disabled"
          schX={0}
          schY={-9.5}
          fontSize={0.2}
        />
      </schematicsheet>
      <schematicsheet
        name="input"
        displayName="Contract-controlled input protection · A1"
        sheetSize="A4"
        sheetIndex={2}
      >
        <schematictext
          text="A1 PROTOTYPE | Contract-controlled input protection · A1 | 2/7"
          schX={0}
          schY={10.2}
          fontSize={0.3}
        />
        <schematictext
          text="DRAFT — schematic validation incomplete — routing disabled"
          schX={0}
          schY={-9.5}
          fontSize={0.2}
        />
      </schematicsheet>
      <schematicsheet
        name="buck"
        displayName="Regulated 5 / 9 / 12 V motor supply · A1"
        sheetSize="A4"
        sheetIndex={3}
      >
        <schematictext
          text="A1 PROTOTYPE | Regulated 5 / 9 / 12 V motor supply · A1 | 3/7"
          schX={0}
          schY={10.2}
          fontSize={0.3}
        />
        <schematictext
          text="DRAFT — schematic validation incomplete — routing disabled"
          schX={0}
          schY={-9.5}
          fontSize={0.2}
        />
      </schematicsheet>
      <schematicsheet
        name="controls"
        displayName="Hardware PWM and REV / OFF / FWD · A1"
        sheetSize="A4"
        sheetIndex={4}
      >
        <schematictext
          text="A1 PROTOTYPE | Hardware PWM and REV / OFF / FWD · A1 | 4/7"
          schX={0}
          schY={10.2}
          fontSize={0.3}
        />
        <schematictext
          text="DRAFT — schematic validation incomplete — routing disabled"
          schX={0}
          schY={-9.5}
          fontSize={0.2}
        />
      </schematicsheet>
      <schematicsheet
        name="protection"
        displayName="Motor rail UV / OV monitoring · A1"
        sheetSize="A4"
        sheetIndex={5}
      >
        <schematictext
          text="A1 PROTOTYPE | Motor rail UV / OV monitoring · A1 | 5/7"
          schX={0}
          schY={10.2}
          fontSize={0.3}
        />
        <schematictext
          text="DRAFT — schematic validation incomplete — routing disabled"
          schX={0}
          schY={-9.5}
          fontSize={0.2}
        />
      </schematicsheet>
      <schematicsheet
        name="motor"
        displayName="Integrated H-bridge and motor output · A1"
        sheetSize="A4"
        sheetIndex={7}
      >
        <schematictext
          text="A1 PROTOTYPE | Integrated H-bridge and motor output · A1 | 7/7"
          schX={0}
          schY={10.2}
          fontSize={0.3}
        />
        <schematictext
          text="DRAFT — schematic validation incomplete — routing disabled"
          schX={0}
          schY={-9.5}
          fontSize={0.2}
        />
      </schematicsheet>
      <schematicsheet
        name="dump"
        displayName="Regenerative energy dump · A1"
        sheetSize="A4"
        sheetIndex={6}
      >
        <schematictext
          text="A1 PROTOTYPE | Regenerative energy dump · A1 | 6/7"
          schX={0}
          schY={10.2}
          fontSize={0.3}
        />
        <schematictext
          text="DRAFT — schematic validation incomplete — routing disabled"
          schX={0}
          schY={-9.5}
          fontSize={0.2}
        />
      </schematicsheet>
      <UsbInput />
      <InputProtection />
      <MotorSupply />
      <PwmControls />
      <RailProtection />
      <EnergyDump />
      <MotorBridge />
    </board>
  )
}
