# USB-C PD brushed motor controller

Revision A1 engineering draft, 2026-10-02. **Schematic approval is blocked by supplier-import rendering defects. Component placement has not started. Routing is disabled. No fabrication-ready or hardware-tested claim is made.**

The failed C6738614 potentiometer is superseded by **Bourns PTV09A-4015F-B103 / C5710902**, imported successfully through JLCPCB. The 10 kΩ pot uses a revised 330 Ω / 5.6 nF diode-steered TLC555 network, approximately 19–21 kHz and 3–97% nominal duty. All electronic components come from unmodified supplier imports; no local symbols, footprints or pin mappings were created.

The circuit draft contains 118 components / 54 unique supplier parts across seven native A4 sheets. It implements an STUSB4500 PD sink, TPS16630 protected input, TPS54360 selectable 5/9/12 V buck, DRV8874 reversible bridge, hardware PWM, direction and voltage selectors, three LEDs, motor screw terminal, transient suppression and a monitored regenerative dump. No MCU is used.

## Review artifacts

- [Schematic entry point](index.circuit.tsx) and functional blocks in `circuit/`.
- [Complete draft BOM](docs/BOM.csv): exact MPNs, manufacturer, package, stock observations, datasheet links and approval status.
- [Power/control calculations and tradeoffs](docs/ARCHITECTURE.md).
- [Requirements and reference review](docs/REQUIREMENTS.md).
- [Placement intent](docs/PLACEMENT.md), explicitly not a placement deliverable.
- [Validation record](VALIDATION.md), including current blockers and check results.
- Seven individually rendered sheets in `dist/review/`: `1-usb.svg` through `7-motor.svg`, with PNGs for visual review. These are marked DRAFT and retain warnings.

With official tscircuit 0.0.2725 / CLI 0.1.2226, formatting, TypeScript and five electrical calculation tests pass; the schematic-only build succeeds. This does **not** establish schematic correctness: the switch imports render only two terminals while the real parts require eight contact terminals. The independent port-coverage audit fails on 11 required connections. Several imported symbols also lack their reference labels. See VALIDATION.md before using any schematic or BOM for fabrication.

## Power and operation intent

Use a USB-C PD charger offering **20 V at 3 A**, or **15 V at 3 A**. The autonomous negotiation requests 20 V first, then 15 V, without relying on a native 12 V PDO. Insufficient chargers leave the motor disabled; they are not used to deliver a reduced motor voltage. This conservative policy also applies to 5/9 V motor modes.

PD NVM must be programmed and read back to the profile in `docs/pd-profile.json` before the motor power stage is used. The file is configuration intent, not a binary programming image. Factory-default NVM is unsuitable for the power budget.

Set the motor-voltage selector **only with USB unplugged**. Default center setting is 5 V; the other positions select 9 and 12 V and track the overvoltage-monitor threshold. Stop the motor and allow it to coast before reversing. Do not assume safe reversal under arbitrary inertia or external back-driving: clamp energy, temperatures and current limits still require physical validation.

At 12 V, 20 V contracts have the better guaranteed input-current margin. A 15 V contract fits the assumed 2 A continuous budget, but worst-case peak margin is limited. Intended operating current is not a measured hardware rating.

## Development

Run commands from this board directory, never the workspace root:

```sh
bun install --frozen-lockfile
bun run format:check
bun run typecheck
bun test
bun run power:report
tsci check netlist index.circuit.tsx
tsci check pin_specification index.circuit.tsx
tsci check source index.circuit.tsx
tsci check schematic-placement index.circuit.tsx
tsci build index.circuit.tsx --disable-pcb --routing-disabled --schematic-svgs
bun scripts/render-schematic-sheets.ts
bun scripts/audit-schematic.ts
```

The last command currently fails on the real missing-port defect; no checks are suppressed. The PCB build / placement command must wait for the schematic and BOM gate. `routingDisabled` is present in the board and project config. Do not enable routing during this review stage.

This task continues the same board-local repository and A0 scaffold. It did not copy another task's board, modify the store application, publish, push or place an order. Failed and unused candidate imports remain for audit; only parts in the manifest/BOM are instantiated in the product circuit.
