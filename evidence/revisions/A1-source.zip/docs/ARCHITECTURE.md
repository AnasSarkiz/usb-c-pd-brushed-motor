# A1 circuit and engineering review

Status: connected circuit draft with unresolved import/validation defects. This document explains implemented intent; it does not approve assembly, routing or physical operating ratings.

## PD and protected input

One TYPE-C-31-M-12 / C165948 is the power input. Separate CC1/CC2 connect to the STUSB4500 / C2678061, with corresponding dead-battery pins tied to their CC lines. USB data and SBU pins are unused. The service header exposes GND, 3.3 V, SCL and SDA; it is not a second USB connector and must not back-power the board.

The requested profile is PDO3 20 V/3 A, PDO2 15 V/3 A, PDO1 5 V/0.5 A, POWER_ONLY_ABOVE_5V=1 and REQ_SRC_CURRENT=0. The [ST decision algorithm](https://www.st.com/resource/en/datasheet/stusb4500.pdf) matches both voltage and available current, highest sink priority first. If neither high-voltage profile matches, operation remains at 5 V and the motor path is inhibited. A 12 V PDO is unnecessary. A 45 W charger lacking 15 V/3 A and 20 V/3 A will be rejected even when it could power a lighter motor load; accepting arbitrary chargers would need dynamic power qualification and would make the control architecture more complex.

The hardware enable has a default-high pull-up on the ST active-low output, with an NPN inversion that holds the eFuse off until the selected contract is valid. The eFuse adds independent UVLO near 13.2 V. Thus ordinary 5/9/12 V input cannot run the motor. **Correctly provisioned NVM is a safety prerequisite:** factory profiles can accept lower currents at high voltage, which the analog voltage detector cannot distinguish. No programmed hardware or NVM readback is claimed.

Two 60 V TPS7A16 LDOs supply 5 V and 3.3 V before the motor gate. The 5 V LDO may be in dropout during initial 5 V attachment; its output remains above the PD controller's minimum supply under the intended light load. LDO dissipation, especially at 20 V, needs exposed-pad copper and bench temperature verification.

D1 is a 22 V standoff input TVS, D2 a dual 24 V CC ESD device, and D3 a 24 V local sense clamp after 1 kΩ. A 24/25 V CC protection family is consistent with ST's [typical interface/reference schematic](https://www.st.com/resource/en/schematic_pack/steval-isc005v1_schematic.pdf); IEC ESD/system transient performance has not been tested. The sense resistor also limits the controller's VBUS discharge current.

SS54 D4 blocks energy returning toward USB. TPS16630PWPR / C1849461 replaced unavailable TPS26630; its actual HTSSOP pinout is used. It provides adjustable UV/OV cutoff, slew control, current limiting, power-good and a floating MODE pin for latch-off. OV is nominally 23.04 V. The 6.8 kΩ ILIM resistor selects 2.647 A nominal; conservative ±10% IC and ±1% resistor bounds give approximately 2.359–2.941 A, leaving some current for the auxiliary supplies within the 3 A contract. Its 22 nF slew capacitor gives approximately 8.8 ms ramp to 20 V from the manufacturer nominal 2 µA/25 V/V model. Inrush into the downstream capacitors and buck-start timing still need a bench check.

## Regulated motor rail

TPS54360DDAR / C44377 is a 60 V, 3.5 A buck, with SS54 catch diode, 8.2 µH Chilisin MHCC10040-8R2M-R7 / C285788, ceramic input bypass and 47+47+220 µF output capacitance plus the bridge's local 47 µF. The inductor family sheet gives 9 A saturation current at 30% inductance loss, 6 A RMS at 40°C rise, and 30 mΩ maximum DCR for the selected part. These are component conditions, not board temperature measurements.

The feedback top is 100 kΩ + 5.1 kΩ. The default bottom is 20 kΩ; switched 21 kΩ and 12 kΩ parallel branches yield nominal 5.004, 9.008 and 12.011 V. Open voltage-selector contacts return to 5 V. Selector labels should be 9 / 5 / 12. Change voltage only while unplugged: a live transition can briefly command the default rail, and stored capacitor energy does not vanish instantly.

162 kΩ RT selects approximately 600 kHz. A provisional 27 kΩ / 22 nF / 22 pF compensation network places its zero near 268 Hz and high-frequency pole near 268 kHz. The [TI small-signal model](https://www.ti.com/lit/ds/symlink/tps54360.pdf), using gmps=12 A/V, gmea=350 µA/V and assumed effective total capacitance 280 µF, estimates crossover near 10.3 kHz at 5 V and 4.3 kHz at 12 V. This is a preliminary calculation: actual ceramic DC bias, electrolytic ESR, Eco-mode and motor PWM loading must be incorporated before loop stability is approved. The shared compensation must be checked in all modes and at light/full load.

Power calculation assumptions: USB voltage -5%; 0.55 V series-diode drop; 85% buck efficiency; 0.3 Ω H-bridge path resistance; 1 W auxiliary budget. These are deliberately explicit assumptions, not measurements.

| Motor mode at 2 A | Assumed input current, 15 V contract | Assumed input current, 20 V contract |
|---|---:|---:|
| 5 V | 1.032 A | 0.767 A |
| 9 V | 1.719 A | 1.277 A |
| 12 V | 2.234 A | 1.660 A |

The 12 V continuous case fits the conservative minimum eFuse limit. At 12 V and 2.4 A, a 15 V contract requires approximately 2.70 A and exceeds that minimum limit; 20 V requires approximately 2.00 A. Therefore peak margin is stronger at 20 V. Actual peak duration/startup success is unresolved and must not be promised for an arbitrary motor.

## Hardware PWM and direction

RV1 is Bourns PTV09A-4015F-B103 / C5710902: 10 kΩ linear, ±20%, 50 mW, 15 mm flat insulated shaft, rear-mount/bushingless configuration. The manufacturer's ordering table and recommended land pattern were visually inspected. It is suitable for a knob normal to the PCB, with enclosure/knob fit still pending. Mechanical tabs are connected to GND. A panel nut is not provided for this bushingless configuration; the enclosure must support the PCB and leave shaft clearance.

The diode-steered TLC555 runs at 3.3 V, with 330 Ω charge and discharge end resistors and 5.6 nF C0G timing capacitance. The analytic estimate includes nominal 0.2 V diode drop and 0.1 V discharge-transistor drop: 19.4–20.9 kHz, about 2.9–96.7% duty. Pot tolerance/residual resistance, threshold variation and diode drops widen this envelope; exact ultrasonic operation across all corners is not guaranteed. The end resistors limit current and avoid zero-time endpoints. OFF is provided by the direction switch, not by expecting precisely 0% duty from the pot.

The direction switch's center throw is unused. Outer throws assert REV or FWD, with 10 kΩ pulldowns. A dual AND gate combines PWM and the selected direction. Driver inputs are low in OFF; the [DRV8874 PWM truth table](https://www.ti.com/lit/ds/symlink/drv8874.pdf) makes this coast. Direction LEDs display the command, not measured rotation or an enabled power stage.

**Switch-import blocker:** the selected C2848921 and two stocked replacement candidates C5274495/C5274498 are emitted as default SPST primitives. Only pins 1/2 render, so the common and other throw connections disappear from the schematic. No definition or symbol was patched. The draft's intended multi-terminal wiring is present in the source netlist but cannot pass schematic review.

## Bridge and output protection

DRV8874PWPR / C1855818 is the single integrated bridge. VM, both grounds and exposed pad, charge-pump reservoir/flying capacitors, PWM mode and IMODE connections follow its physical pin table. VREF=3.3 V and IPROPI=3.3 kΩ select approximately 2.22 A nominal chopping current, providing modest margin over 2 A. Current-sense accuracy is not guaranteed by the quoted datasheet table at a 5 V rail; this mode needs a measured current-limit characterization. No arbitrary 2.5 A continuous rating is claimed.

MOTOR+ and MOTOR− connect directly to DB126V-5.0-2P-GN-P / C395849. Neither motor terminal is ground; polarity reverses in reverse. Local 100 nF/47 µF decoupling, bidirectional SMBJ15CA suppression across the motor and rail, and the upstream controlled input form the protection draft. The TVS is a backup transient limiter, not a continuous regenerative load.

TL431 plus LM393 monitors the rail. Undervoltage inhibits the timer and bridge at about 91% of the selected setpoint. Input power-good also holds the bridge off during startup. A separate selector pole changes the OV divider; positive feedback provides hysteresis. With the high output pulled toward VM by the PNP stage, approximate OV on/off thresholds are 5.66/5.54, 10.34/9.94 and 13.89/13.17 V, rather than a falsely constant 2.495 V comparator reference.

OV turns on the AO3400A dump MOSFET through a PNP driver and 10 V gate clamp, and disables buck/bridge. Four 10 Ω/2 W resistors form two series branches in parallel: 10 Ω and 8 W aggregate continuous component rating. At the highest threshold, the instantaneous load is about 19 W. Pulse-energy capability and thermal placement are **unapproved**. It cannot absorb an indefinitely back-driven motor, and arbitrary immediate reversal is outside the currently established envelope. Actual winding inductance, inertia, stall demand and recovery behavior remain prototype test requirements.
