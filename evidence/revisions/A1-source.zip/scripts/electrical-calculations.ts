export interface PdCapability {
  voltageV: number
  currentA: number
}

// STUSB4500 autonomous matching: higher priority first; voltage AND current.
export function chooseMotorContract(sourceCapabilities: PdCapability[]) {
  for (const voltageV of [20, 15]) {
    if (
      sourceCapabilities.some(
        (capability) =>
          capability.voltageV === voltageV && capability.currentA >= 3,
      )
    ) {
      return { voltageV, currentA: 3 }
    }
  }
  return null
}

export function motorInputCurrentA({
  motorVoltageV,
  motorCurrentA,
  contractVoltageV,
}: {
  motorVoltageV: number
  motorCurrentA: number
  contractVoltageV: number
}) {
  const minimumSourceVoltageV = contractVoltageV * 0.95
  const assumedDiodeDropV = 0.55
  const assumedBridgeResistanceOhms = 0.3
  const assumedBuckEfficiency = 0.85
  const assumedAuxiliaryPowerW = 1
  const bridgeLossW = motorCurrentA ** 2 * assumedBridgeResistanceOhms
  return (
    (motorVoltageV * motorCurrentA + bridgeLossW) /
      assumedBuckEfficiency /
      (minimumSourceVoltageV - assumedDiodeDropV) +
    assumedAuxiliaryPowerW / minimumSourceVoltageV
  )
}

export function regulatedMotorVoltageV(parallelBranchOhms?: number) {
  const feedbackTopOhms = 100_000 + 5_100
  const feedbackBottomOhms = parallelBranchOhms
    ? 1 / (1 / 20_000 + 1 / parallelBranchOhms)
    : 20_000
  return 0.8 * (1 + feedbackTopOhms / feedbackBottomOhms)
}

export function pwmTiming({
  fraction,
  potResistanceOhms = 10_000,
  timingCapacitanceF = 5.6e-9,
}: {
  fraction: number
  potResistanceOhms?: number
  timingCapacitanceF?: number
}) {
  // Analytic estimate including diode and discharge transistor drops.
  // These nominal drops are assumptions; no simulated/bench guarantee.
  const supplyV = 3.3
  const diodeDropV = 0.2
  const dischargeDropV = 0.1
  const lowerThresholdV = supplyV / 3
  const upperThresholdV = (supplyV * 2) / 3
  const chargeTimeS =
    timingCapacitanceF *
    (330 + fraction * potResistanceOhms) *
    Math.log(
      (supplyV - diodeDropV - lowerThresholdV) /
        (supplyV - diodeDropV - upperThresholdV),
    )
  const dischargeTimeS =
    timingCapacitanceF *
    (330 + (1 - fraction) * potResistanceOhms) *
    Math.log(
      (upperThresholdV - diodeDropV - dischargeDropV) /
        (lowerThresholdV - diodeDropV - dischargeDropV),
    )
  return {
    frequencyHz: 1 / (chargeTimeS + dischargeTimeS),
    dutyFraction: chargeTimeS / (chargeTimeS + dischargeTimeS),
  }
}
