import { readFile, writeFile } from "node:fs/promises"
import { any_circuit_element } from "circuit-json"
import { z } from "zod"

const circuitJson = z
  .array(any_circuit_element)
  .parse(JSON.parse(await readFile("dist/index/circuit.json", "utf8")))
const manifest = z
  .array(
    z.object({
      ref: z.string(),
      code: z.string(),
      pins: z.record(z.string(), z.string()),
      nc: z.array(z.string()),
    }),
  )
  .parse(JSON.parse(await readFile("docs/design-manifest.json", "utf8")))
const issues: string[] = []
for (const part of manifest) {
  const sourceComponent = circuitJson.find(
    (element) =>
      element.type === "source_component" && element.name === part.ref,
  )
  if (!sourceComponent || sourceComponent.type !== "source_component") {
    issues.push(`${part.ref} ${part.code}: source component missing`)
    continue
  }
  for (const [pinAlias, expectedNet] of Object.entries(part.pins)) {
    const sourcePort = circuitJson.find(
      (element) =>
        element.type === "source_port" &&
        element.source_component_id === sourceComponent.source_component_id &&
        (element.name === pinAlias || element.port_hints?.includes(pinAlias)),
    )
    if (!sourcePort || sourcePort.type !== "source_port") {
      issues.push(`${part.ref} ${part.code} ${pinAlias}: source port missing`)
      continue
    }
    const schematicPort = circuitJson.find(
      (element) =>
        element.type === "schematic_port" &&
        element.source_port_id === sourcePort.source_port_id,
    )
    if (!schematicPort) {
      issues.push(
        `${part.ref} ${part.code} ${pinAlias} -> ${expectedNet}: required connection has no schematic port`,
      )
    }
  }
}
const report = {
  revision: "A1",
  componentCount: manifest.length,
  requiredPinsWithoutSchematicPorts: issues,
  pcbTraceCount: circuitJson.filter((element) => element.type === "pcb_trace")
    .length,
}
await writeFile(
  "evidence/schematic-port-audit-A1.json",
  `${JSON.stringify(report, null, 2)}\n`,
)
console.log(JSON.stringify(report, null, 2))
if (issues.length > 0) process.exitCode = 1
