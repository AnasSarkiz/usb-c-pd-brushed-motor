import { distance, rotation } from "circuit-json"
import { expectTypesMatch } from "lib/typecheck"
import { z } from "zod"
import { point } from "./point"
import { point3 } from "./point3"

export interface KicadAt {
  x: number | string
  y: number | string
  rotation?: number | string
}

export const kicadAt = point.extend({
  rotation: rotation.optional(),
})

type InferredKicadAt = z.input<typeof kicadAt>
expectTypesMatch<KicadAt, InferredKicadAt>(true)

export interface KicadFont {
  size?: { x: number | string; y: number | string }
  thickness?: number | string
}

export const kicadFont = z.object({
  size: point.optional(),
  thickness: distance.optional(),
})

type InferredKicadFont = z.input<typeof kicadFont>
expectTypesMatch<KicadFont, InferredKicadFont>(true)

export interface KicadEffects {
  font?: KicadFont
}

export const kicadEffects = z.object({
  font: kicadFont.optional(),
})

type InferredKicadEffects = z.input<typeof kicadEffects>
expectTypesMatch<KicadEffects, InferredKicadEffects>(true)

export interface KicadProperty {
  value: string
  at?: KicadAt
  layer?: string
  uuid?: string
  hide?: boolean
  effects?: KicadEffects
}

export const kicadProperty = z.object({
  value: z.string(),
  at: kicadAt.optional(),
  layer: z.string().optional(),
  uuid: z.string().optional(),
  hide: z.boolean().optional(),
  effects: kicadEffects.optional(),
})

type InferredKicadProperty = z.input<typeof kicadProperty>
expectTypesMatch<KicadProperty, InferredKicadProperty>(true)

export interface KicadFootprintProperties {
  Reference?: KicadProperty
  Value?: KicadProperty
  Datasheet?: KicadProperty
  Description?: KicadProperty
}

export const kicadFootprintProperties = z.object({
  Reference: kicadProperty.optional(),
  Value: kicadProperty.optional(),
  Datasheet: kicadProperty.optional(),
  Description: kicadProperty.optional(),
})

type InferredKicadFootprintProperties = z.input<typeof kicadFootprintProperties>
expectTypesMatch<KicadFootprintProperties, InferredKicadFootprintProperties>(
  true,
)

export interface KicadFootprintAttributes {
  through_hole?: boolean
  smd?: boolean
  exclude_from_pos_files?: boolean
  exclude_from_bom?: boolean
}

export const kicadFootprintAttributes = z.object({
  through_hole: z.boolean().optional(),
  smd: z.boolean().optional(),
  exclude_from_pos_files: z.boolean().optional(),
  exclude_from_bom: z.boolean().optional(),
})

type InferredKicadFootprintAttributes = z.input<typeof kicadFootprintAttributes>
expectTypesMatch<KicadFootprintAttributes, InferredKicadFootprintAttributes>(
  true,
)

export interface KicadFootprintPad {
  name: string
  type: string
  shape?: string
  at?: KicadAt
  size?: { x: number | string; y: number | string }
  drill?: number | string
  layers?: string[]
  removeUnusedLayers?: boolean
  uuid?: string
}

export const kicadFootprintPad = z.object({
  name: z.string(),
  type: z.string(),
  shape: z.string().optional(),
  at: kicadAt.optional(),
  size: point.optional(),
  drill: distance.optional(),
  layers: z.array(z.string()).optional(),
  removeUnusedLayers: z.boolean().optional(),
  uuid: z.string().optional(),
})

type InferredKicadFootprintPad = z.input<typeof kicadFootprintPad>
expectTypesMatch<KicadFootprintPad, InferredKicadFootprintPad>(true)

export interface KicadFootprintModel {
  path: string
  offset?: { x: number | string; y: number | string; z: number | string }
  scale?: { x: number | string; y: number | string; z: number | string }
  rotate?: { x: number | string; y: number | string; z: number | string }
}

export const kicadFootprintModel = z.object({
  path: z.string(),
  offset: point3.optional(),
  scale: point3.optional(),
  rotate: point3.optional(),
})

type InferredKicadFootprintModel = z.input<typeof kicadFootprintModel>
expectTypesMatch<KicadFootprintModel, InferredKicadFootprintModel>(true)

export interface KicadFootprintMetadata {
  footprintName?: string
  version?: number | string
  generator?: string
  generatorVersion?: number | string
  layer?: string
  properties?: KicadFootprintProperties
  attributes?: KicadFootprintAttributes
  pads?: KicadFootprintPad[]
  embeddedFonts?: boolean
  model?: KicadFootprintModel
}

export const kicadFootprintMetadata = z.object({
  footprintName: z.string().optional(),
  version: z.union([z.number(), z.string()]).optional(),
  generator: z.string().optional(),
  generatorVersion: z.union([z.number(), z.string()]).optional(),
  layer: z.string().optional(),
  properties: kicadFootprintProperties.optional(),
  attributes: kicadFootprintAttributes.optional(),
  pads: z.array(kicadFootprintPad).optional(),
  embeddedFonts: z.boolean().optional(),
  model: kicadFootprintModel.optional(),
})

type InferredKicadFootprintMetadata = z.input<typeof kicadFootprintMetadata>
expectTypesMatch<KicadFootprintMetadata, InferredKicadFootprintMetadata>(true)
