import { pcbLayoutProps, type PcbLayoutProps } from "lib/common/layout"
import { expectTypesMatch } from "lib/typecheck"
import { z } from "zod"

export interface BreakoutPointProps
  extends Omit<PcbLayoutProps, "pcbRotation"> {
  /** Physical PCB layer of the escape target. Omission preserves the current
   * routing-layer choice. Uses the canonical layout layer input/normalization.
   * A target on another layer requires actual routed vias; it does not move or
   * alter the connected supplier pad. No aliases or changed default. */
  layer?: PcbLayoutProps["layer"]
  connection: string
}

export const breakoutPointProps = pcbLayoutProps
  .omit({ pcbRotation: true })
  .extend({
    connection: z.string(),
  })

type InferredBreakoutPointProps = z.input<typeof breakoutPointProps>
expectTypesMatch<BreakoutPointProps, InferredBreakoutPointProps>(true)
