# @tscircuit/props

This repo contains all the prop definitions and zod parsers for tscircuit builtin TSX components, e.g. `<resistor />`, `<diode />`,
`<capacitor />` etc. All tscircuit features typically start with a new props definition.

[Contributor Getting Started Video](https://share.cleanshot.com/jLkhVjDj)

This repo is the source-of-truth for defining the React props, API changes begin here. The focus of the API is on ergonomics for
the user (unlike [circuit-json](https://github.com/tscircuit/circuit-json) which focuses on ergonomics for a renderer)

```ts
import type { ResistorProps, ResistorPropsInput } from "@tscircuit/props";
import { resistorProps } from "@tscircuit/props";

resistorProps.parse({ resistance: "10k" } as ResistorPropsInput);
// { resistance: 10_000 }
```

<!-- COMPONENT_TABLE_START -->

## Available Components

| Component                               | Props Interface                                                                                                    |
| --------------------------------------- | ------------------------------------------------------------------------------------------------------------------ |
| `<ammeter />`                           | [`AmmeterProps`](#ammeterprops-ammeter)                                                                            |
| `<analog.acsweepsimulation />`          | [`AnalogAcSweepSimulationProps`](#analogacsweepsimulationprops-analogacsweepsimulation)                            |
| `<analog.dcoperatingpointsimulation />` | [`AnalogDcOperatingPointSimulationProps`](#analogdcoperatingpointsimulationprops-analogdcoperatingpointsimulation) |
| `<analog.dcsweepsimulation />`          | [`AnalogDcSweepSimulationProps`](#analogdcsweepsimulationprops-analogdcsweepsimulation)                            |
| `<analogsimulation />`                  | [`AnalogSimulationProps`](#analogsimulationprops-analogsimulation)                                                 |
| `<analog.sweepparameter />`             | [`AnalogResistanceSweepParameterProps`](#analogresistancesweepparameterprops-analogsweepparameter)                 |
| `<analog.transientsimulation />`        | [`AnalogTransientSimulationProps`](#analogtransientsimulationprops-analogtransientsimulation)                      |
| `<antenna />`                           | [`AntennaProps`](#antennaprops-antenna)                                                                            |
| `<autoroutingphase />`                  | [`AutoroutingPhaseProps`](#autoroutingphaseprops-autoroutingphase)                                                 |
| `<battery />`                           | [`BatteryProps`](#batteryprops-battery)                                                                            |
| `<board />`                             | [`BoardProps`](#boardprops-board)                                                                                  |
| `<breakout />`                          | [`BreakoutProps`](#breakoutprops-breakout)                                                                         |
| `<breakoutpoint />`                     | [`BreakoutPointProps`](#breakoutpointprops-breakoutpoint)                                                          |
| `<bus />`                               | [`BusProps`](#busprops-bus)                                                                                        |
| `<cadassembly />`                       | [`CadAssemblyProps`](#cadassemblyprops-cadassembly)                                                                |
| `<cadmodel />`                          | [`CadModelProps`](#cadmodelprops-cadmodel)                                                                         |
| `<capacitor />`                         | [`CapacitorProps`](#capacitorprops-capacitor)                                                                      |
| `<chip />`                              | [`ChipProps`](#chipprops-chip)                                                                                     |
| `<connector />`                         | [`ConnectorProps`](#connectorprops-connector)                                                                      |
| `<constrainedlayout />`                 | [`ConstrainedLayoutProps`](#constrainedlayoutprops-constrainedlayout)                                              |
| `<constraint />`                        | [`ConstraintProps`](#constraintprops-constraint)                                                                   |
| `<copperpour />`                        | [`CopperPourProps`](#copperpourprops-copperpour)                                                                   |
| `<coppertext />`                        | [`CopperTextProps`](#coppertextprops-coppertext)                                                                   |
| `<courtyardcircle />`                   | [`CourtyardCircleProps`](#courtyardcircleprops-courtyardcircle)                                                    |
| `<courtyardoutline />`                  | [`CourtyardOutlineProps`](#courtyardoutlineprops-courtyardoutline)                                                 |
| `<courtyardpill />`                     | [`CourtyardPillProps`](#courtyardpillprops-courtyardpill)                                                          |
| `<courtyardrect />`                     | [`CourtyardRectProps`](#courtyardrectprops-courtyardrect)                                                          |
| `<crystal />`                           | [`CrystalProps`](#crystalprops-crystal)                                                                            |
| `<currentsource />`                     | [`CurrentSourceProps`](#currentsourceprops-currentsource)                                                          |
| `<cutout />`                            | [`RectCutoutProps`](#rectcutoutprops-cutout)                                                                       |
| `<differentialpair />`                  | [`DifferentialPairProps`](#differentialpairprops-differentialpair)                                                 |
| `<diode />`                             | [`DiodeProps`](#diodeprops-diode)                                                                                  |
| `<drccheck />`                          | [`DrcCheckProps`](#drccheckprops-drccheck)                                                                         |
| `<fabricationnotedimension />`          | [`FabricationNoteDimensionProps`](#fabricationnotedimensionprops-fabricationnotedimension)                         |
| `<fabricationnotepath />`               | [`FabricationNotePathProps`](#fabricationnotepathprops-fabricationnotepath)                                        |
| `<fabricationnoterect />`               | [`FabricationNoteRectProps`](#fabricationnoterectprops-fabricationnoterect)                                        |
| `<fabricationnotetext />`               | [`FabricationNoteTextProps`](#fabricationnotetextprops-fabricationnotetext)                                        |
| `<fiducial />`                          | [`FiducialProps`](#fiducialprops-fiducial)                                                                         |
| `<footprint />`                         | [`FootprintProps`](#footprintprops-footprint)                                                                      |
| `<fuse />`                              | [`FuseProps`](#fuseprops-fuse)                                                                                     |
| `<group />`                             | [`BaseGroupProps`](#basegroupprops-group)                                                                          |
| `<hole />`                              | [`CircleHoleProps`](#circleholeprops-hole)                                                                         |
| `<inductor />`                          | [`InductorProps`](#inductorprops-inductor)                                                                         |
| `<interconnect />`                      | [`InterconnectProps`](#interconnectprops-interconnect)                                                             |
| `<internalcircuit />`                   | [`InternalCircuitProps`](#internalcircuitprops-internalcircuit)                                                    |
| `<jumper />`                            | [`JumperProps`](#jumperprops-jumper)                                                                               |
| `<led />`                               | [`LedProps`](#ledprops-led)                                                                                        |
| `<mosfet />`                            | [`MosfetProps`](#mosfetprops-mosfet)                                                                               |
| `<mountedboard />`                      | [`MountedBoardProps`](#mountedboardprops-mountedboard)                                                             |
| `<net />`                               | [`NetProps`](#netprops-net)                                                                                        |
| `<netalias />`                          | [`NetAliasProps`](#netaliasprops-netalias)                                                                         |
| `<netlabel />`                          | [`NetLabelProps`](#netlabelprops-netlabel)                                                                         |
| `<opamp />`                             | [`OpAmpProps`](#opampprops-opamp)                                                                                  |
| `<panel />`                             | [`PanelProps`](#panelprops-panel)                                                                                  |
| `<pcbbend />`                           | [`PcbBendProps`](#pcbbendprops-pcbbend)                                                                            |
| `<pcbkeepout />`                        | [`PcbKeepoutProps`](#pcbkeepoutprops-pcbkeepout)                                                                   |
| `<pcbnotedimension />`                  | [`PcbNoteDimensionProps`](#pcbnotedimensionprops-pcbnotedimension)                                                 |
| `<pcbnoteline />`                       | [`PcbNoteLineProps`](#pcbnotelineprops-pcbnoteline)                                                                |
| `<pcbnotepath />`                       | [`PcbNotePathProps`](#pcbnotepathprops-pcbnotepath)                                                                |
| `<pcbnoterect />`                       | [`PcbNoteRectProps`](#pcbnoterectprops-pcbnoterect)                                                                |
| `<pcbnotetext />`                       | [`PcbNoteTextProps`](#pcbnotetextprops-pcbnotetext)                                                                |
| `<pcbsoldermaskopening />`              | [`PcbSoldermaskOpeningProps`](#pcbsoldermaskopeningprops-pcbsoldermaskopening)                                     |
| `<pcbstiffener />`                      | [`PcbStiffenerProps`](#pcbstiffenerprops-pcbstiffener)                                                             |
| `<pcbtrace />`                          | [`PcbTraceProps`](#pcbtraceprops-pcbtrace)                                                                         |
| `<pinheader />`                         | [`PinHeaderProps`](#pinheaderprops-pinheader)                                                                      |
| `<pinout />`                            | [`PinoutProps`](#pinoutprops-pinout)                                                                               |
| `<platedhole />`                        | [`CirclePlatedHoleProps`](#circleplatedholeprops-platedhole)                                                       |
| `<port />`                              | [`PortProps`](#portprops-port)                                                                                     |
| `<potentiometer />`                     | [`PotentiometerProps`](#potentiometerprops-potentiometer)                                                          |
| `<powersource />`                       | [`PowerSourceProps`](#powersourceprops-powersource)                                                                |
| `<pushbutton />`                        | [`PushButtonProps`](#pushbuttonprops-pushbutton)                                                                   |
| `<resistor />`                          | [`ResistorProps`](#resistorprops-resistor)                                                                         |
| `<resonator />`                         | [`ResonatorProps`](#resonatorprops-resonator)                                                                      |
| `<schematicarc />`                      | [`SchematicArcProps`](#schematicarcprops-schematicarc)                                                             |
| `<schematicbox />`                      | [`SchematicBoxProps`](#schematicboxprops-schematicbox)                                                             |
| `<schematiccell />`                     | [`SchematicCellProps`](#schematiccellprops-schematiccell)                                                          |
| `<schematiccircle />`                   | [`SchematicCircleProps`](#schematiccircleprops-schematiccircle)                                                    |
| `<schematicgraphic />`                  | [`SchematicGraphicProps`](#schematicgraphicprops-schematicgraphic)                                                 |
| `<schematicline />`                     | [`SchematicLineProps`](#schematiclineprops-schematicline)                                                          |
| `<schematicpath />`                     | [`SchematicPathProps`](#schematicpathprops-schematicpath)                                                          |
| `<schematicrect />`                     | [`SchematicRectProps`](#schematicrectprops-schematicrect)                                                          |
| `<schematicrow />`                      | [`SchematicRowProps`](#schematicrowprops-schematicrow)                                                             |
| `<schematicsection />`                  | [`SchematicSectionProps`](#schematicsectionprops-schematicsection)                                                 |
| `<schematicsheet />`                    | [`SchematicSheetProps`](#schematicsheetprops-schematicsheet)                                                       |
| `<schematicsymbol />`                   | [`SchematicSymbolProps`](#schematicsymbolprops-schematicsymbol)                                                    |
| `<schematictable />`                    | [`SchematicTableProps`](#schematictableprops-schematictable)                                                       |
| `<schematictext />`                     | [`SchematicTextProps`](#schematictextprops-schematictext)                                                          |
| `<silkscreencircle />`                  | [`SilkscreenCircleProps`](#silkscreencircleprops-silkscreencircle)                                                 |
| `<silkscreengraphic />`                 | [`SilkscreenGraphicProps`](#silkscreengraphicprops-silkscreengraphic)                                              |
| `<silkscreenline />`                    | [`SilkscreenLineProps`](#silkscreenlineprops-silkscreenline)                                                       |
| `<silkscreenpath />`                    | [`SilkscreenPathProps`](#silkscreenpathprops-silkscreenpath)                                                       |
| `<silkscreenrect />`                    | [`SilkscreenRectProps`](#silkscreenrectprops-silkscreenrect)                                                       |
| `<silkscreentext />`                    | [`SilkscreenTextProps`](#silkscreentextprops-silkscreentext)                                                       |
| `<smtpad />`                            | [`RectSmtPadProps`](#rectsmtpadprops-smtpad)                                                                       |
| `<solderjumper />`                      | [`SolderJumperProps`](#solderjumperprops-solderjumper)                                                             |
| `<solderpaste />`                       | [`RectSolderPasteProps`](#rectsolderpasteprops-solderpaste)                                                        |
| `<spicemodel />`                        | [`SpiceModelProps`](#spicemodelprops-spicemodel)                                                                   |
| `<stampboard />`                        | [`StampboardProps`](#stampboardprops-stampboard)                                                                   |
| `<subcircuit />`                        | [`SubcircuitProps`](#subcircuitprops-subcircuit)                                                                   |
| `<subpanel />`                          | [`SubpanelProps`](#subpanelprops-subpanel)                                                                         |
| `<switch />`                            | [`SwitchProps`](#switchprops-switch)                                                                               |
| `<symbol />`                            | [`SymbolProps`](#symbolprops-symbol)                                                                               |
| `<testpoint />`                         | [`TestpointProps`](#testpointprops-testpoint)                                                                      |
| `<toolingrail />`                       | [`ToolingrailProps`](#toolingrailprops-toolingrail)                                                                |
| `<trace />`                             | [`TraceProps`](#traceprops-trace)                                                                                  |
| `<tracehint />`                         | [`TraceHintProps`](#tracehintprops-tracehint)                                                                      |
| `<transistor />`                        | [`TransistorProps`](#transistorprops-transistor)                                                                   |
| `<via />`                               | [`ViaProps`](#viaprops-via)                                                                                        |
| `<voltageprobe />`                      | [`VoltageProbeProps`](#voltageprobeprops-voltageprobe)                                                             |
| `<voltagesource />`                     | [`VoltageSourceProps`](#voltagesourceprops-voltagesource)                                                          |

<!-- COMPONENT_TABLE_END -->

<!-- USAGE_EXAMPLES_START -->

## Usage Examples

```tsx
import { resistorProps, type ResistorProps } from "@tscircuit/props";

// Validate component props
const validatedProps = resistorProps.parse({ resistance: "10k" });
// { resistance: 10000 }

// Type safety
const myResistor: ResistorProps = {
  name: "R1",
  resistance: 10000,
  footprint: "0805",
};
```

<!-- USAGE_EXAMPLES_END -->

<!-- INTERFACE_DEFINITIONS_START -->

## Component Interface Definitions

Below are the TypeScript interface definitions for all component props:

### CommonComponentProps

```ts
export interface CommonComponentProps extends CommonLayoutProps {
  key?: any;
  name: string;
  pinAttributes?: Record<PinLabel, PinAttributeMap>;
  supplierPartNumbers?: SupplierPartNumbers;
  cadModel?: CadModelProp;
  children?: any;
  symbolName?: string;
  doNotPlace?: boolean;
  /**
   * This component will be drawn as part of this section e.g. "Power"
   */
  schSectionName?: string;
  /**
   * This component will be drawn as part of this sheet e.g. "Main"
   */
  schSheetName?: string;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/common/layout.ts)

### SubcircuitGroupProps

```ts
export interface SubcircuitGroupProps extends BaseGroupProps {
  manualEdits?: ManualEditsFileInput;
  routingDisabled?: boolean;
  defaultTraceWidth?: Distance;
  minTraceWidth?: Distance;
  nominalTraceWidth?: Distance;
  pcbRouteCache?: PcbRouteCache;

  autorouter?: AutorouterProp;
  preflightRoutingCheckPolicy?: PreflightRoutingCheckPolicy;
  exposedNets?: string[];
  exposeNets?: boolean;

  /**
   * If true, we'll automatically layout the schematic for this group. Must be
   * a subcircuit (currently). This is eventually going to be replaced with more
   * sophisticated layout options/modes and will be enabled by default.
   */
  schAutoLayoutEnabled?: boolean;

  /**
   * If true, net labels will automatically be created for complex traces
   */
  schTraceAutoLabelEnabled?: boolean;

  /** Maximum length a trace can span on the schematic */
  schMaxTraceDistance?: Distance;

  partsEngine?: PartsEngine;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/group.ts)

### AmmeterProps `<ammeter />`

```ts
export interface AmmeterProps<
  PinLabel extends string = string,
> extends CommonComponentProps<PinLabel> {
  connections: Connections<AmmeterPinLabels>;
  color?: string;
  graphDisplayName?: string;
  graphCenter?: number;
  graphVerticalOffset?: number | string;
  graphCurrentPerDiv?: number | string;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/ammeter.ts)

### AnalogAcSweepSimulationProps `<analog.acsweepsimulation />`

```ts
export interface AnalogAcSweepSimulationProps extends AnalogAnalysisSimulationBaseProps {
  /** Frequency spacing used by the AC analysis. */
  sweepType: "linear" | "decade" | "octave";
  /** First positive frequency. Raw numbers are hertz. */
  startFrequency: number | string;
  /** Last frequency, which must be greater than startFrequency. Raw numbers are hertz. */
  stopFrequency: number | string;
  /** Samples per decade or octave; required for non-linear sweeps. */
  samplesPerInterval?: number;
  /** Total samples; required for linear sweeps. */
  sampleCount?: number;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/analogacsweepsimulation.ts)

### AnalogDcOperatingPointSimulationProps `<analog.dcoperatingpointsimulation />`

```ts
export type AnalogDcOperatingPointSimulationProps =
  AnalogAnalysisSimulationBaseProps;
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/analogdcoperatingpointsimulation.ts)

### AnalogDcSweepSimulationProps `<analog.dcsweepsimulation />`

```ts
export interface AnalogDcSweepSimulationProps extends AnalogAnalysisSimulationBaseProps {
  /** Selector for the independent voltage or current source being swept. */
  sweepSource: string;
  /** First source level. Raw numbers use volts or amperes according to the source. */
  sweepStart: number | string;
  /** Last source level. Raw numbers use volts or amperes according to the source. */
  sweepStop: number | string;
  /** Nonzero increment directed from sweepStart toward sweepStop. */
  sweepStep: number | string;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/analogdcsweepsimulation.ts)

### AnalogSimulationProps `<analogsimulation />`

```ts
export interface AnalogSimulationProps {
  name?: string;
  simulationType?: "spice_transient_analysis";
  duration?: number | string;
  startTime?: number | string;
  timePerStep?: number | string;
  spiceEngine?: AutocompleteString<"spicey" | "ngspice">;
  spiceOptions?: SpiceOptions;
  graphIndependentAxes?: boolean;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/analogsimulation.ts)

### AnalogResistanceSweepParameterProps `<analog.sweepparameter />`

```ts
export interface AnalogResistanceSweepParameterProps extends AnalogSweepCoordinatesProps {
  parameterType: "resistance";
  /** Selector for the resistor whose simulation-only resistance is swept. */
  resistorRef: string;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/analogsweepparameter.ts)

### AnalogTransientSimulationProps `<analog.transientsimulation />`

```ts
export interface AnalogTransientSimulationProps extends AnalogAnalysisSimulationBaseProps {
  /** Simulation duration. Raw numbers are milliseconds. Defaults to 10ms. */
  duration?: number | string;
  /** Time at which recording starts. Raw numbers are milliseconds. Defaults to 0ms. */
  startTime?: number | string;
  /** Maximum simulation timestep. Raw numbers are milliseconds. Defaults to 0.01ms. */
  timePerStep?: number | string;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/analogtransientsimulation.ts)

### AntennaProps `<antenna />`

```ts
export interface AntennaProps extends CommonComponentProps {
  /**
   * Band-qualified PCB-trace topology to generate. The encoded band is enough
   * to select the geometry without frequencyBand. No shape is assumed when
   * omitted. An explicit pcbPath takes precedence when both are provided.
   */
  antennaShape?: AntennaShape;
  /**
   * Nominal operating band or multiband configuration. This is redundant when
   * antennaShape is present; the band encoded in antennaShape controls generated
   * geometry.
   */
  frequencyBand?: AntennaFrequencyBand;
  /**
   * Explicit antenna path. Entries use the same selector, point, and via
   * syntax as trace pcbPath entries.
   */
  pcbPath?: PcbPath;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/antenna.ts)

### AutoroutingPhaseProps `<autoroutingphase />`

```ts
export interface AutoroutingPhaseProps extends RoutingTolerances, FanoutProps {
  key?: any;
  name?: string;
  autorouter?: AutorouterProp;
  /**
   * Custom async routing function accepting simple route JSON and returning the
   * routing result, using the same contract as autorouter.algorithmFn. Parsing
   * preserves the function unchanged. Omitted by default; no aliases or prop
   * conflicts are introduced, and existing phases require no migration.
   */
  algorithmFn?: AutorouterConfig["algorithmFn"];
  preflightRoutingCheckPolicy?: PreflightRoutingCheckPolicy;
  phaseIndex?: number;
  /**
   * Saved PCB wire/via routes using the same format as fanout pcbTracePaths.
   * Numeric distances are mm; unit strings are normalized to mm. Omitted by
   * default; an empty array is accepted. No aliases or prop conflicts are
   * introduced, and existing phases require no migration.
   */
  pcbTracePaths?: FanoutTracePath[];
  region?: {
    shape?: "rect";
    minX: number;
    maxX: number;
    minY: number;
    maxY: number;
  };
  connection?: string;
  connections?: string[];
  // Reroutes traces selected by region or connection. The simplify autorouter
  // may omit a selector to simplify every existing trace in the phase.
  reroute?: boolean;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/autoroutingphase.ts)

### BatteryProps `<battery />`

```ts
export interface BatteryProps<
  PinLabel extends string = string,
> extends CommonComponentProps<PinLabel> {
  capacity?: number | string;
  voltage?: number | string;
  standard?: "AA" | "AAA" | "9V" | "CR2032" | "18650" | "C";
  schOrientation?: SchematicOrientation;
  connections?: Connections<BatteryPinLabels>;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/battery.ts)

### BoardProps `<board />`

````ts
export interface BoardProps extends Omit<
  SubcircuitGroupProps,
  "subcircuit" | "connections" | "outline"
> {
  title?: string;
  /**
   * Assembly mounting target, such as "NEMA17.backface". Trimmed; omitted
   * leaves the board unattached. The target face is resolved by the consumer.
   */
  mountedTo?: string;
  /**
   * Nonnegative finite clearance between the target mounting face and the
   * nearest PCB surface, in millimeters or a unit string. Parsed to mm.
   * Omitted leaves the gap unset; only meaningful when mountedTo is supplied.
   */
  mountGap?: Distance;
  /** Fabricator preset, preserved as supplied. Omitted leaves the preset unset. */
  fabricatorPreset?:
    | "jlcpcb_economy"
    | "jlcpcb_standard"
    | "jlcpcb_economy_20260912"
    | "jlcpcb_standard_20260912";
  material?: "fr4" | "fr1" | "flex";
  /** Number of layers for the PCB */
  layers?: 1 | 2 | 4 | 6 | 8 | 10;
  /**
   * Whether the autorouter may generate blind and buried vias. Defaults to
   * false, which restricts newly generated vias to the full board stack.
   */
  allowBlindAndBuriedVias?: boolean;
  /**
   * Whether to route remaining unrouted connections after explicit routing phases.
   * Omitted leaves the setting unset, preserving the consumer's default behavior.
   */
  routeRemaining?: boolean;
  defaultViaTenting?:
    | boolean
    | "both_sides"
    | "top_and_bottom_tented"
    | "top_tented"
    | "bottom_tented"
    | "exposed";
  borderRadius?: Distance;
  thickness?: Distance;
  boardAnchorPosition?: Point;
  anchorAlignment?: z.infer<typeof ninePointAnchor>;
  boardAnchorAlignment?: z.infer<typeof ninePointAnchor>;
  /**
   * Points defining the board edge. Set `isCastellatedHole` on a point to
   * place a castellated plated hole centered on that location.
   *
   * @example
   * ```tsx
   * { x: "-5mm", y: 0, isCastellatedHole: true,
   *   holeDiameter: "0.8mm", padDiameter: "1.2mm",
   *   connectsTo: "net.GND" }
   * ```
   */
  outline?: BoardOutlinePoint[];
  /** Color applied to both top and bottom solder masks */
  solderMaskColor?: BoardColor;
  /** Color of the top solder mask */
  topSolderMaskColor?: BoardColor;
  /** Color of the bottom solder mask */
  bottomSolderMaskColor?: BoardColor;
  /** Color applied to both top and bottom silkscreens */
  silkscreenColor?: BoardColor;
  /** Color of the top silkscreen */
  topSilkscreenColor?: BoardColor;
  /** Color of the bottom silkscreen */
  bottomSilkscreenColor?: BoardColor;
  /** Whether the board should be assembled on both sides */
  doubleSidedAssembly?: boolean;
  /** Whether vias may be placed inside PCB pads */
  isViaInPadAllowed?: boolean;
  /**
   * Stencil layers for plated through-hole pads: none for hand/wave soldering,
   * top, bottom, or both for pin-in-paste. Omitted preserves legacy both-layer
   * paste generation. Parsed unchanged; no aliases or conflicts. SMT paste is
   * unaffected. Existing designs require no migration.
   */
  pcbPlatedHoleSolderPaste?: "none" | "top" | "bottom" | "both";
  /**
   * Whether implicit copper pours should be generated automatically. Defaults
   * to false.
   */
  automaticPoursEnabled?: boolean;
  /** Whether to stitch copper pours on the same net across layers with vias. Defaults to false. */
  enableViaStitching?: boolean;
  /** Positive center-to-center stitching via spacing in millimeters or a unit string. Omitted uses the solver default. Does not enable stitching by itself. */
  viaStitchPitch?: Distance;
  /** Whether this board should be omitted from the schematic view */
  schematicDisabled?: boolean;
}
````

[Source](https://github.com/tscircuit/props/blob/main/lib/components/board.ts)

### BreakoutProps `<breakout />`

```ts
export interface BreakoutProps
  extends Omit<SubcircuitGroupProps, "subcircuit">, FanoutProps {
  /**
   * Autorouter used to escape the components inside the breakout boundary.
   * Defaults to the multilayer fanout autorouter.
   * `"dogbone"` selects local pad-to-via escapes without boundary routing.
   * Accepted as a preset string or `{ preset: "dogbone" }`; parsing preserves
   * the selected form. This adds an explicit preset with no aliases or changes
   * to the default. Routing requires a core version supporting this preset.
   */
  autorouter?: AutorouterProp;
  /**
   * Saved port-to-exit wire/via routes in the fanout's local PCB frame.
   * Numeric distances are mm; unit strings are normalized to mm. Each route
   * must start at its selected port and end at its fanout exit. Layers name
   * physical board layers. Either endpoint may be a via when permitted by
   * the circuit's routing rules (e.g. allowViaInPad for a via at a pad).
   * Core creates the exits and preserves saved copper.
   * When supplied, replaces automatic routing (including `autorouter`) for
   * this fanout and must cover all its routing connections. Do not also add
   * a breakoutpoint/fanoutpoint for the same port. Omitted by default; existing
   * automatic fanouts are unchanged. No aliases or migration are required.
   */
  pcbTracePaths?: FanoutTracePath[];
  padding?: Distance;
  paddingLeft?: Distance;
  paddingRight?: Distance;
  paddingTop?: Distance;
  paddingBottom?: Distance;
  /**
   * Minimum clearance between this fanout boundary and another fanout
   * boundary. Fanout boundaries may never overlap, even when this is omitted.
   */
  fanoutMargin?: Distance;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/breakout.ts)

### BreakoutPointProps `<breakoutpoint />`

```ts
export interface BreakoutPointProps extends Omit<
  PcbLayoutProps,
  "pcbRotation"
> {
  /** Physical PCB layer of the escape target. Omission preserves the current
   * routing-layer choice. Uses the canonical layout layer input/normalization.
   * A target on another layer requires actual routed vias; it does not move or
   * alter the connected supplier pad. No aliases or changed default. */
  layer?: PcbLayoutProps["layer"];
  connection: string;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/breakoutpoint.ts)

### BusProps `<bus />`

```ts
export interface BusProps {
  name?: string;
  /** One or more trace names or port selectors for the connections in the bus. */
  connections: string[];
  /** If set, every trace in this bus is assigned to this autorouting phase. */
  routingPhaseIndex?: number | null;
  /** Maximum routed-length difference between bus members. Raw numbers are millimeters. */
  maxLengthSkew?: number | string;
  /** Intended single-ended characteristic impedance. Raw numbers are ohms. */
  targetImpedance?: number | string;
  /** Explicit PCB trace width for every bus member. Raw numbers are millimeters. */
  pcbTraceWidth?: number | string;
  /** PCB layers on which the bus may be routed. */
  pcbAllowedLayers?: LayerRefInput[];
  /** Preferred PCB layer for routing the bus. */
  preferredLayer?: LayerRefInput;
  /** Preferred PCB layers for routing the bus, in priority order. */
  preferredLayers?: LayerRefInput[];
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/bus.ts)

### CadAssemblyProps `<cadassembly />`

```ts
export interface CadAssemblyProps {
  /**
   * The layer that the CAD assembly is designed for. If you set this to "top"
   * then it means the children were intended to represent the top layer. If
   * the <chip /> with this assembly is moved to the bottom layer, then the
   * components will be mirrored.
   *
   * Generally, you shouldn't set this except where it can help prevent
   * confusion because you have a complex multi-layer assembly. Default is
   * "top" and this is most intuitive.
   */
  originalLayer?: LayerRef;

  children?: any;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/cadassembly.ts)

### CadModelProps `<cadmodel />`

```ts
export interface CadModelProps extends CadModelBase {
  modelUrl: string;
  stepUrl?: string;
  pcbX?: Distance;
  pcbY?: Distance;
  pcbLeftEdgeX?: Distance;
  pcbRightEdgeX?: Distance;
  pcbTopEdgeY?: Distance;
  pcbBottomEdgeY?: Distance;
  pcbOffsetX?: Distance;
  pcbOffsetY?: Distance;
  pcbZ?: Distance;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/cadmodel.ts)

### CapacitorProps `<capacitor />`

```ts
export interface CapacitorProps<
  PinLabel extends string = string,
> extends CommonComponentProps<PinLabel> {
  capacitance: number | string;
  maxVoltageRating?: number | string;
  schShowRatings?: boolean;
  polarized?: boolean;
  decouplingFor?: string;
  decouplingTo?: string;
  bypassFor?: string;
  bypassTo?: string;
  /** Maximum allowed PCB trace length between this capacitor and the component it decouples */
  maxDecouplingTraceLength?: number | string;
  schOrientation?: SchematicOrientation;
  schSize?: SchematicSymbolSize;
  connections?: Connections<CapacitorPinLabels>;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/capacitor.ts)

### ChipProps `<chip />`

```ts
export interface ChipPropsSU<
  PinLabel extends SchematicPinLabel = SchematicPinLabel,
> extends CommonComponentProps<PinLabel> {
  manufacturerPartNumber?: string;
  pinLabels?: PinLabelsProp<SchematicPinLabel, PinLabel>;
  /**
   * Whether to show pin aliases in the schematic
   */
  showPinAliases?: boolean;
  /**
   * Labels for PCB pins
   */
  pcbPinLabels?: Record<string, string>;
  schPinArrangement?: SchematicPortArrangement;
  /** @deprecated Use schPinArrangement instead. */
  schPortArrangement?: SchematicPortArrangement;
  pinCompatibleVariants?: PinCompatibleVariant[];
  schPinStyle?: SchematicPinStyle;
  /** @deprecated Use schPinStyle instead. */
  schPinSpacing?: Distance;
  schWidth?: Distance;
  schHeight?: Distance;
  noSchematicRepresentation?: boolean;
  /**
   * Whether to show the components from `internalCircuit` in the schematic.
   * When false, the chip's schematic box is shown instead.
   * @default false
   */
  schShowInternalCircuit?: boolean;
  internallyConnectedPins?: (string | number)[][];
  externallyConnectedPins?: string[][];
  /**
   * Pins intentionally left unconnected. This is a shorthand for marking
   * those pins as do-not-connect without repeating pinAttributes entries.
   */
  noConnect?: readonly PinLabel[] | PinLabel[];
  connections?: Connections<PinLabel>;
  spiceModel?: SpiceModelElement;
  /**
   * Functional components contained inside this physical chip package,
   * wrapped in an `<internalcircuit />` element.
   */
  internalCircuit?: InternalCircuitElement;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/chip.ts)

### ConnectorProps `<connector />`

```ts
export interface ConnectorProps extends ChipPropsSU {
  /**
   * Connector interface or product family, e.g. usb_c, m2, jst_ph
   */
  standard?: ConnectorStandard;

  /**
   * Number of electrical circuits in the connector
   */
  pinCount?: number;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/connector.ts)

### ConstrainedLayoutProps `<constrainedlayout />`

```ts
export interface ConstrainedLayoutProps {
  name?: string;
  pcbOnly?: boolean;
  schOnly?: boolean;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/constrainedlayout.ts)

### ConstraintProps `<constraint />`

```ts
export type ConstraintProps =
  | PcbXDistConstraint
  | PcbYDistConstraint
  | PcbSameYConstraint
  | PcbSameXConstraint;

// -----------------------------------------------------------------------------
// Zod
// -----------------------------------------------------------------------------
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/constraint.ts)

### CopperPourProps `<copperpour />`

```ts
export interface CopperPourProps {
  name?: string;
  layer: LayerRefInput;
  connectsTo: string;
  /**
   * Fill with a 45-degree crosshatch (defaults: 0.25mm copper width, 1mm pitch).
   * Preserves solid copper around boundaries and connections. Defaults to false.
   */
  crosshatch?: boolean;
  /** Repeat spacing perpendicular to the hatch strips. Defaults to 1mm when crosshatch is enabled. */
  crosshatchPitch?: Distance;
  /** Copper strip width, also used for the solid rim. Defaults to 0.25mm; must be less than the pitch when crosshatch is enabled. */
  crosshatchWidth?: Distance;
  /**
   * Reserves the pour region during autorouting so unrelated traces do not
   * split it. Vias may still cross the region using antipads.
   */
  unbroken?: boolean;
  padMargin?: Distance;
  traceMargin?: Distance;
  clearance?: Distance;
  boardEdgeMargin?: Distance;
  cutoutMargin?: Distance;
  useThermalReliefs?: boolean;
  outline?: Point[];
  coveredWithSolderMask?: boolean;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/copper-pour.ts)

### CopperTextProps `<coppertext />`

```ts
export type CopperTextProps = z.input<typeof copperTextProps>;
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/copper-text.ts)

### CourtyardCircleProps `<courtyardcircle />`

```ts
export type CourtyardCircleProps = z.input<typeof courtyardCircleProps>;
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/courtyard-circle.ts)

### CourtyardOutlineProps `<courtyardoutline />`

```ts
export type CourtyardOutlineProps = z.input<typeof courtyardOutlineProps>;
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/courtyard-outline.ts)

### CourtyardPillProps `<courtyardpill />`

```ts
export type CourtyardPillProps = z.input<typeof courtyardPillProps>;
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/courtyard-pill.ts)

### CourtyardRectProps `<courtyardrect />`

```ts
export type CourtyardRectProps = z.input<typeof courtyardRectProps>;
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/courtyard-rect.ts)

### CrystalProps `<crystal />`

```ts
export interface CrystalProps<
  PinLabel extends string = string,
> extends CommonComponentProps<PinLabel> {
  frequency: number | string;
  loadCapacitance: number | string;
  /** Maximum allowed PCB trace length between the crystal and its connected component */
  maxTraceLength?: number | string;
  manufacturerPartNumber?: string;
  pinVariant?: PinVariant;
  schOrientation?: SchematicOrientation;
  connections?: Connections<CrystalPinLabels>;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/crystal.ts)

### CurrentSourceProps `<currentsource />`

```ts
export interface CurrentSourceProps<
  PinLabel extends string = string,
> extends CommonComponentProps<PinLabel> {
  current?: number | string;
  frequency?: number | string;
  peakToPeakCurrent?: number | string;
  waveShape?: WaveShape;
  phase?: number | string;
  dutyCycle?: number | string;
  /** Small-signal AC magnitude. Raw numbers are amperes. */
  acMagnitude?: number | string;
  /** Small-signal AC phase. Raw numbers are degrees. */
  acPhase?: number | string;
  connections?: Connections<CurrentSourcePinLabels>;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/currentsource.ts)

### RectCutoutProps `<cutout />`

```ts
export interface RectCutoutProps extends Omit<
  PcbLayoutProps,
  "layer" | "pcbRotation"
> {
  name?: string;
  shape: "rect";
  width: Distance;
  height: Distance;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/cutout.ts)

### DifferentialPairProps `<differentialpair />`

```ts
export interface DifferentialPairProps {
  name?: string;
  /** Name of the trace or pin carrying the positive signal. */
  positiveConnection: string;
  /** Name of the trace or pin carrying the negative signal. */
  negativeConnection: string;
  /** Maximum permitted routed-length skew. Raw numbers are millimeters. */
  maxLengthSkew?: number | string;
  /** Intended differential characteristic impedance. Raw numbers are ohms. */
  targetDifferentialImpedance?: number | string;
  /** Edge-to-edge PCB copper gap between the pair. Raw numbers are millimeters. */
  pcbTraceGap?: number | string;
  /** Maximum length over which the pair may be routed without coupling. Raw numbers are millimeters. */
  maxUncoupledLength?: number | string;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/differentialpair.ts)

### DiodeProps `<diode />`

```ts
export interface DiodeProps<
  PinLabel extends string = string,
> extends CommonComponentProps<PinLabel> {
  pinLabels?: DiodePinLabelsProp<PinLabel>;
  connections?: {
    anode?: string | string[] | readonly string[];
    cathode?: string | string[] | readonly string[];
    pin1?: string | string[] | readonly string[];
    pin2?: string | string[] | readonly string[];
    pos?: string | string[] | readonly string[];
    neg?: string | string[] | readonly string[];
  };
  variant?: "standard" | "schottky" | "zener" | "avalanche" | "photo" | "tvs";
  standard?: boolean;
  schottky?: boolean;
  zener?: boolean;
  avalanche?: boolean;
  photo?: boolean;
  tvs?: boolean;
  schOrientation?: SchematicOrientation;
  /** Select a compact schematic symbol; omitted, default, and md retain the standard symbol. */
  schSize?: SchematicSymbolSize;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/diode.ts)

### DrcCheckProps `<drccheck />`

```ts
export interface DrcCheckProps {
  name?: string;
  checkFn: CustomDrcCheckFn;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/drc-check.ts)

### FabricationNoteDimensionProps `<fabricationnotedimension />`

```ts
export interface FabricationNoteDimensionProps extends Omit<
  PcbLayoutProps,
  | "pcbLeftEdgeX"
  | "pcbRightEdgeX"
  | "pcbTopEdgeY"
  | "pcbBottomEdgeY"
  | "pcbX"
  | "pcbY"
  | "pcbOffsetX"
  | "pcbOffsetY"
  | "pcbRotation"
> {
  from: string | Point;
  to: string | Point;
  text?: string;
  /** Offset distance in mm, or a unit-bearing string. Defaults to no offset. */
  offset?: string | number;
  /**
   * Unitless direction in footprint-local coordinates (+X right, +Y up).
   * Preserved as supplied; omitted uses the perpendicular to from -> to.
   * The direction rotates/mirrors with the footprint, without translation.
   */
  offsetDirection?: { x: number; y: number };
  font?: "tscircuit2024";
  fontSize?: string | number;
  color?: string;
  arrowSize?: string | number;
  units?: "in" | "mm";
  outerEdgeToEdge?: true;
  centerToCenter?: true;
  innerEdgeToEdge?: true;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/fabrication-note-dimension.ts)

### FabricationNotePathProps `<fabricationnotepath />`

```ts
export type FabricationNotePathProps = z.input<typeof fabricationNotePathProps>;
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/fabrication-note-path.ts)

### FabricationNoteRectProps `<fabricationnoterect />`

```ts
export type FabricationNoteRectProps = z.input<typeof fabricationNoteRectProps>;
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/fabrication-note-rect.ts)

### FabricationNoteTextProps `<fabricationnotetext />`

```ts
export interface FabricationNoteTextProps extends PcbLayoutProps {
  text: string;
  anchorAlignment?:
    "center" | "top_left" | "top_right" | "bottom_left" | "bottom_right";
  font?: "tscircuit2024";
  fontSize?: string | number;
  color?: string;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/fabrication-note-text.ts)

### FiducialProps `<fiducial />`

```ts
export interface FiducialProps extends CommonComponentProps {
  soldermaskPullback?: Distance;
  padDiameter: Distance;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/fiducial.ts)

### FootprintProps `<footprint />`

```ts
export interface FootprintProps {
  children?: any;
  name?: string;
  /**
   * The layer that the footprint is designed for. If you set this to "top"
   * then it means the children were intended to represent the top layer. If
   * the <chip /> with this footprint is moved to the bottom layer, then the
   * components will be mirrored.
   *
   * Generally, you shouldn't set this except where it can help prevent
   * confusion because you have a complex multi-layer footprint. Default is
   * "top" and this is most intuitive.
   */
  originalLayer?: LayerRef;
  /**
   * Serialized circuit JSON describing a precompiled footprint
   */
  circuitJson?: any[];
  /**
   * Can be a footprint or kicad string
   */
  src?: FootprintProp;
  /**
   * Direction a cable or mating part is attached from, in the footprint's own
   * frame -- the same frame its pads are drawn in. Directions are named for the
   * footprint as drawn in the 2D PCB view: `from_top` is +Y, `from_bottom` -Y,
   * `from_left` -X, `from_right` +X, `from_above` +Z and `from_below` -Z.
   * Cartesian spellings such as `from_y_pos` are also accepted.
   *
   * This names a side, not a motion. A receptacle on the +Y edge is `from_top`
   * because that is the side the plug comes from, even though the plug itself
   * moves in -Y as it seats.
   *
   * This is a property of the part, so it is authored without regard to where
   * the part is placed. Rotating or flipping the component rotates this with it,
   * and `pcb_component.insertion_direction` reports the result in board
   * coordinates. The two frames coincide for an unrotated top-layer part, which
   * makes the distinction easy to miss.
   */
  insertionDirection?: FootprintInsertionDirection;
  /**
   * Direction the part's enclosure opening faces, named the same way as
   * `insertionDirection` and in the same unrotated part frame.
   *
   * These are two different physical facts and a part may need both. A
   * side-actuated switch is *installed* from above and *actuated* from the side:
   * its aperture must pierce a side wall, while nothing is ever inserted into
   * it. Reusing `insertionDirection` for that would either put the opening on
   * the wrong face or overload a field documented as "the side exposing the
   * receptacle where the cable is attached".
   *
   * Like `insertionDirection`, this is a property of the part, authored without
   * regard to placement: rotating or flipping the component rotates it too, and
   * `pcb_component.cutout_aperture_direction` reports the result in board
   * coordinates.
   *
   * When absent, the aperture falls back to `insertionDirection`, which is
   * correct for every connector -- a cable enters through the opening it needs.
   */
  cutoutApertureDirection?: FootprintInsertionDirection;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/footprint.ts)

### FuseProps `<fuse />`

```ts
export interface FuseProps<
  PinLabel extends string = string,
> extends CommonComponentProps<PinLabel> {
  /**
   * Current rating of the fuse in amperes
   */
  currentRating: number | string;

  /**
   * Voltage rating of the fuse
   */
  voltageRating?: number | string;

  /**
   * Whether to show ratings on schematic
   */
  schShowRatings?: boolean;

  schOrientation?: SchematicOrientation;

  /**
   * Connections to other components
   */
  connections?: Connections<PinLabel>;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/fuse.ts)

### BaseGroupProps

```ts
export interface BaseGroupProps extends CommonLayoutProps, LayoutConfig {
  name?: string;
  key?: any;
  children?: any;

  pcbStyle?: PcbStyle;

  /**
   * Title to display above this group in the schematic view
   */
  schTitle?: string;

  /**
   * This group will be drawn as part of this sheet e.g. "Main"
   */
  schSheetName?: string;

  /**
   * If true, render this group as a single schematic box
   */
  showAsSchematicBox?: boolean;

  /**
   * Mapping of external pin names to internal connection targets
   */
  connections?: Connections;

  /**
   * Arrangement for pins when rendered as a schematic box
   */
  schPinArrangement?: SchematicPinArrangement;

  /**
   * Spacing between pins when rendered as a schematic box
   * @deprecated Use schPinStyle instead.
   */
  schPinSpacing?: Distance;

  /**
   * Styles to apply to individual pins in the schematic box representation
   */
  schPinStyle?: SchematicPinStyle;

  pcbWidth?: Distance;
  pcbHeight?: Distance;
  minTraceWidth?: Distance;
  nominalTraceWidth?: Distance;
  schWidth?: Distance;
  schHeight?: Distance;

  pcbLayout?: LayoutConfig;
  schLayout?: LayoutConfig;
  cellBorder?: Border | null;
  border?: Border | null;
  schPadding?: Distance;
  schPaddingLeft?: Distance;
  schPaddingRight?: Distance;
  schPaddingTop?: Distance;
  schPaddingBottom?: Distance;

  pcbPadding?: Distance;
  pcbPaddingLeft?: Distance;
  pcbPaddingRight?: Distance;
  pcbPaddingTop?: Distance;
  pcbPaddingBottom?: Distance;
  /**
   * Anchor to use when interpreting pcbX/pcbY/pcbOffsetX/pcbOffsetY relative to pcbPosition
   */
  pcbAnchorAlignment?: AutocompleteString<z.infer<typeof ninePointAnchor>>;

  /** @deprecated Use `pcbGrid` */
  grid?: boolean;
  /** @deprecated Use `pcbFlex` */
  flex?: boolean | string;

  pcbGrid?: boolean;
  pcbGridCols?: number | string;
  pcbGridRows?: number | string;
  pcbGridTemplateRows?: string;
  pcbGridTemplateColumns?: string;
  pcbGridTemplate?: string;
  pcbGridGap?: number | string;
  pcbGridRowGap?: number | string;
  pcbGridColumnGap?: number | string;

  pcbFlex?: boolean | string;
  pcbFlexGap?: number | string;
  pcbFlexDirection?: "row" | "column";
  pcbAlignItems?: "start" | "center" | "end" | "stretch";
  pcbJustifyContent?:
    | "start"
    | "center"
    | "end"
    | "stretch"
    | "space-between"
    | "space-around"
    | "space-evenly";
  pcbFlexRow?: boolean;
  pcbFlexColumn?: boolean;
  pcbGap?: number | string;
  pcbPack?: boolean;
  pcbPackGap?: number | string;

  schGrid?: boolean;
  schGridCols?: number | string;
  schGridRows?: number | string;
  schGridTemplateRows?: string;
  schGridTemplateColumns?: string;
  schGridTemplate?: string;
  schGridGap?: number | string;
  schGridRowGap?: number | string;
  schGridColumnGap?: number | string;

  schFlex?: boolean | string;
  schFlexGap?: number | string;
  schFlexDirection?: "row" | "column";
  schAlignItems?: "start" | "center" | "end" | "stretch";
  schJustifyContent?:
    | "start"
    | "center"
    | "end"
    | "stretch"
    | "space-between"
    | "space-around"
    | "space-evenly";
  schFlexRow?: boolean;
  schFlexColumn?: boolean;
  schGap?: number | string;
  schPack?: boolean;
  schMatchAdapt?: boolean;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/group.ts)

### CircleHoleProps `<hole />`

```ts
export interface CircleHoleProps extends PcbLayoutProps {
  name?: string;
  shape?: "circle";
  diameter?: Distance;
  radius?: Distance;
  solderMaskMargin?: Distance;
  coveredWithSolderMask?: boolean;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/hole.ts)

### InductorProps `<inductor />`

```ts
export interface InductorProps<
  PinLabel extends string = string,
> extends CommonComponentProps<PinLabel> {
  inductance: number | string;
  maxCurrentRating?: number | string;
  schOrientation?: SchematicOrientation;
  connections?: Connections<InductorPinLabels>;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/inductor.ts)

### InterconnectProps `<interconnect />`

```ts
export interface InterconnectProps extends CommonComponentProps {
  standard?: "TSC0001_36P_XALT_2025_11" | "0805" | "0603" | "1206";
  pinLabels?: Record<
    number | SchematicPinLabel,
    SchematicPinLabel | SchematicPinLabel[]
  >;
  /**
   * Groups of pins that are internally connected
   * e.g., [["1","2"], ["2","3"]]
   */
  internallyConnectedPins?: (string | number)[][];
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/interconnect.ts)

### InternalCircuitProps `<internalcircuit />`

```ts
export interface InternalCircuitProps {
  children?: ReactNode;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/internal-circuit.ts)

### JumperProps `<jumper />`

```ts
export interface JumperProps extends CommonComponentProps {
  manufacturerPartNumber?: string;
  pinLabels?: Record<
    number | SchematicPinLabel,
    SchematicPinLabel | SchematicPinLabel[]
  >;
  schPinStyle?: SchematicPinStyle;
  /** @deprecated Use schPinStyle instead. */
  schPinSpacing?: number | string;
  schWidth?: number | string;
  schHeight?: number | string;
  schDirection?: "left" | "right";
  schPinArrangement?: SchematicPortArrangement;
  /**
   * @deprecated Use schPinArrangement instead.
   */
  schPortArrangement?: SchematicPortArrangement;
  /**
   * Labels for PCB pins
   */
  pcbPinLabels?: Record<string, string>;
  /**
   * Number of pins on the jumper (2 or 3)
   */
  pinCount?: 2 | 3;
  /**
   * Groups of pins that are internally connected
   * e.g., [["1","2"], ["2","3"]]
   */
  internallyConnectedPins?: (string | number)[][];
  /**
   * Connections to other components
   */
  connections?: Connections<string>;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/jumper.ts)

### LedProps `<led />`

```ts
export type LedProps = z.input<typeof ledProps>;
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/led.ts)

### MosfetProps `<mosfet />`

```ts
export interface MosfetProps<
  PinLabel extends string = string,
> extends CommonComponentProps<PinLabel> {
  channelType: "n" | "p";
  mosfetMode: "enhancement" | "depletion";
  /** The side of the schematic symbol where the drain port is placed. */
  symbolDrainSide?: "left" | "right" | "top" | "bottom";
  /** The side of the schematic symbol where the source port is placed. */
  symbolSourceSide?: "left" | "right" | "top" | "bottom";
  /** The side of the schematic symbol where the gate port is placed. */
  symbolGateSide?: "left" | "right" | "top" | "bottom";
  connections?: Connections<MosfetPinLabels>;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/mosfet.ts)

### MountedBoardProps `<mountedboard />`

```ts
export interface MountedBoardProps
  extends SubcircuitGroupProps, MountedBoardChipProps {
  boardToBoardDistance?: Distance;
  mountOrientation?: "faceDown" | "faceUp";
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/mountedboard.ts)

### NetProps `<net />`

```ts
export interface NetProps {
  name: string;
  connectsTo?: string | string[];
  routingPhaseIndex?: number | null;
  highlightColor?: string;
  isPowerNet?: boolean;
  isGroundNet?: boolean;
  nominalTraceWidth?: Distance;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/net.ts)

### NetAliasProps `<netalias />`

```ts
export interface NetAliasProps {
  net?: string;
  connection?: string;
  schX?: number | string;
  schY?: number | string;
  schRotation?: number | string;
  anchorSide?: "left" | "top" | "right" | "bottom";
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/netalias.ts)

### NetLabelProps `<netlabel />`

```ts
export interface NetLabelProps {
  net?: string;
  connection?: string;
  connectsTo?: string | string[];
  /**
   * Render the net name along its schematic trace instead of as an anchored
   * label. Inline placement is automatic, so schematic anchor positioning
   * props are ignored.
   */
  inline?: boolean;
  schX?: number | string;
  schY?: number | string;
  schRotation?: number | string;
  anchorSide?: "left" | "top" | "right" | "bottom";
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/netlabel.ts)

### OpAmpProps `<opamp />`

```ts
export interface OpAmpProps<
  PinLabel extends string = string,
> extends CommonComponentProps<PinLabel> {
  connections?: Connections<OpAmpPinLabels>;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/opamp.ts)

### PanelProps `<panel />`

```ts
export interface PanelProps extends Omit<
  BaseGroupProps,
  "height" | "layoutMode" | "width"
> {
  width?: Distance;
  height?: Distance;
  children?: BaseGroupProps["children"];
  anchorAlignment?: z.infer<typeof ninePointAnchor>;
  /**
   * If true, prevent a solder mask from being applied to this panel.
   */
  noSolderMask?: boolean;
  /**
   * Method used to separate boards in the panel.
   *
   * `outline_routing` creates continuous routed cutouts around each board
   * outline without tabs.
   */
  panelizationMethod?: "tab-routing" | "outline_routing" | "none";
  /** Gap between boards in a panel */
  boardGap?: Distance;
  layoutMode?: "grid" | "pack" | "none";
  row?: number;
  col?: number;
  cellWidth?: Distance;
  cellHeight?: Distance;
  tabWidth?: Distance;
  tabLength?: Distance;
  mouseBites?: boolean;
  edgePadding?: Distance;
  edgePaddingLeft?: Distance;
  edgePaddingRight?: Distance;
  edgePaddingTop?: Distance;
  edgePaddingBottom?: Distance;
  _subcircuitCachingEnabled?: boolean;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/panel.ts)

### PcbBendProps `<pcbbend />`

```ts
export interface PcbBendProps {
  name?: string;
  /** Start/end of the bend-zone centerline in the parent PCB coordinate system. */
  x1: Distance;
  y1: Distance;
  x2: Distance;
  y2: Distance;
  /** Signed degrees (or an angle string). Positive folds toward the local top face. */
  bendAngle: number | string;
  /** Positive neutral-surface radius, in mm or a distance string. */
  bendRadius: Distance;
  /**
   * Radius of circular tear-relief cutouts centered at both bend endpoints in
   * the flat PCB. Removes material to round the edge where each cutout meets
   * the board outline. Finite and positive, in mm or a distance string;
   * parsed to mm. Omit to leave the outline unchanged (no tear reliefs).
   * Independent of bendRadius and bendSide; no aliases or conflicting props.
   */
  tearReliefRadius?: Distance;
  /** Moving side, looking from (x1, y1) toward (x2, y2) in the flat layout. */
  bendSide: "left" | "right";
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/pcb-bend.ts)

### PcbKeepoutProps `<pcbkeepout />`

```ts
export type PcbKeepoutProps = z.input<typeof pcbKeepoutProps>;
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/pcb-keepout.ts)

### PcbNoteDimensionProps `<pcbnotedimension />`

```ts
export interface PcbNoteDimensionProps extends Omit<
  PcbLayoutProps,
  | "pcbLeftEdgeX"
  | "pcbRightEdgeX"
  | "pcbTopEdgeY"
  | "pcbBottomEdgeY"
  | "pcbX"
  | "pcbY"
  | "pcbOffsetX"
  | "pcbOffsetY"
  | "pcbRotation"
> {
  from: string | Point;
  to: string | Point;
  text?: string;
  /** Offset distance in mm, or a unit-bearing string. Defaults to no offset. */
  offset?: string | number;
  /**
   * Unitless direction in footprint-local coordinates (+X right, +Y up).
   * Preserved as supplied; omitted uses the perpendicular to from -> to.
   * The direction rotates/mirrors with the footprint, without translation.
   */
  offsetDirection?: { x: number; y: number };
  font?: "tscircuit2024";
  fontSize?: string | number;
  color?: string;
  arrowSize?: string | number;
  units?: "in" | "mm";
  outerEdgeToEdge?: true;
  centerToCenter?: true;
  innerEdgeToEdge?: true;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/pcb-note-dimension.ts)

### PcbNoteLineProps `<pcbnoteline />`

```ts
export interface PcbNoteLineProps extends Omit<
  PcbLayoutProps,
  | "pcbLeftEdgeX"
  | "pcbRightEdgeX"
  | "pcbTopEdgeY"
  | "pcbBottomEdgeY"
  | "pcbX"
  | "pcbY"
  | "pcbOffsetX"
  | "pcbOffsetY"
  | "pcbRotation"
> {
  x1: string | number;
  y1: string | number;
  x2: string | number;
  y2: string | number;
  strokeWidth?: string | number;
  color?: string;
  isDashed?: boolean;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/pcb-note-line.ts)

### PcbNotePathProps `<pcbnotepath />`

```ts
export interface PcbNotePathProps extends Omit<
  PcbLayoutProps,
  | "pcbLeftEdgeX"
  | "pcbRightEdgeX"
  | "pcbTopEdgeY"
  | "pcbBottomEdgeY"
  | "pcbX"
  | "pcbY"
  | "pcbOffsetX"
  | "pcbOffsetY"
  | "pcbRotation"
> {
  route: RouteHintPointInput[];
  strokeWidth?: string | number;
  color?: string;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/pcb-note-path.ts)

### PcbNoteRectProps `<pcbnoterect />`

```ts
export interface PcbNoteRectProps extends Omit<PcbLayoutProps, "pcbRotation"> {
  width: string | number;
  height: string | number;
  strokeWidth?: string | number;
  isFilled?: boolean;
  hasStroke?: boolean;
  isStrokeDashed?: boolean;
  color?: string;
  cornerRadius?: string | number;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/pcb-note-rect.ts)

### PcbNoteTextProps `<pcbnotetext />`

```ts
export interface PcbNoteTextProps extends PcbLayoutProps {
  text: string;
  anchorAlignment?:
    "center" | "top_left" | "top_right" | "bottom_left" | "bottom_right";
  font?: "tscircuit2024";
  fontSize?: string | number;
  color?: string;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/pcb-note-text.ts)

### PcbSoldermaskOpeningProps `<pcbsoldermaskopening />`

```ts
export type PcbSoldermaskOpeningProps = z.input<
  typeof pcbSoldermaskOpeningProps
>;
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/pcb-soldermask-opening.ts)

### PcbStiffenerProps `<pcbstiffener />`

```ts
export type PcbStiffenerProps = z.input<typeof pcbStiffenerProps>;
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/pcb-stiffener.ts)

### PcbTraceProps `<pcbtrace />`

```ts
export type PcbTraceProps = z.input<typeof pcbTraceProps>;
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/pcb-trace.ts)

### PinHeaderProps `<pinheader />`

```ts
export interface PinHeaderProps extends CommonComponentProps {
  /**
   * Number of pins in the header
   */
  pinCount: number;

  /**
   * Distance between pins
   */
  pitch?: number | string;

  /**
   * Schematic facing direction
   */
  schFacingDirection?: "up" | "down" | "left" | "right";

  /**
   * Whether the header is male, female, or unpopulated
   */
  gender?: "male" | "female" | "unpopulated";

  /**
   * Mount the header on the top of the board, so it is connected to from
   * above. An alias for `layer: "top"`, which is the default.
   *
   * Which side of the board a part sits on is `layer`, and only `layer`: the
   * 3D model is always drawn top-side and consumers flip it for a bottom-layer
   * component. Prefer these names on a connector, where "which side does the
   * mating connector come from" is the question actually being asked.
   */
  connectsFromAbove?: boolean;

  /**
   * Mount the header on the underside of the board, so it is connected to from
   * below. An alias for `layer: "bottom"`.
   *
   * Not to be confused with `invert` on a footprint string, which installs a
   * header BACKWARDS on whichever side it is on — long pins through the board
   * rather than short ones.
   */
  connectsFromBelow?: boolean;

  /**
   * Whether to show pin labels in silkscreen
   */
  showSilkscreenPinLabels?: boolean;

  /**
   * Labels for PCB pins
   */
  pcbPinLabels?: Record<string, string>;

  /**
   * Whether the header has two rows of pins
   */
  doubleRow?: boolean;

  /**
   * If true, the header is a right-angle style connector
   */
  rightAngle?: boolean;

  /**
   * Orientation of the header on the PCB
   */
  pcbOrientation?: PcbOrientation;

  /**
   * Diameter of the through-hole for each pin
   */
  holeDiameter?: number | string;

  /**
   * Diameter of the plated area around each hole
   */
  platedDiameter?: number | string;

  /**
   * Labels for each pin
   */
  pinLabels?: Record<string, SchematicPinLabel> | SchematicPinLabel[];

  /**
   * Connections to other components
   */
  connections?: Connections<string>;

  /**
   * Direction the header is facing
   */
  facingDirection?: "left" | "right";

  /**
   * Pin arrangement in schematic view
   */
  schPinArrangement?: SchematicPinArrangement;

  /**
   * Schematic pin style (margins, etc)
   */
  schPinStyle?: SchematicPinStyle;

  /**
   * Schematic pin spacing
   * @deprecated Use schPinStyle instead.
   */
  schPinSpacing?: number | string;

  /**
   * Schematic width
   */
  schWidth?: number | string;

  /**
   * Schematic height
   */
  schHeight?: number | string;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/pin-header.ts)

### CirclePlatedHoleProps `<platedhole />`

```ts
export interface CirclePlatedHoleProps extends Omit<
  PcbLayoutProps,
  "pcbRotation" | "layer"
> {
  name?: string;
  connectsTo?: string | string[];
  shape: "circle";
  holeDiameter: number | string;
  outerDiameter: number | string;
  padDiameter?: number | string;
  portHints?: PortHints;
  solderMaskMargin?: Distance;
  coveredWithSolderMask?: boolean;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/platedhole.ts)

### PortProps `<port />`

```ts
export type PortProps = z.input<typeof portProps>;
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/port.ts)

### PotentiometerProps `<potentiometer />`

```ts
export interface PotentiometerProps<
  PinLabel extends string = string,
> extends CommonComponentProps<PinLabel> {
  maxResistance: number | string;
  pinVariant?: PotentiometerPinVariant;
  connections?: Connections<PotentiometerPinLabels>;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/potentiometer.ts)

### PowerSourceProps `<powersource />`

```ts
export type PowerSourceProps = z.input<typeof powerSourceProps>;
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/power-source.ts)

### PushButtonProps `<pushbutton />`

```ts
export type PushButtonProps<T extends PinLabelsProp | string = string> =
  ChipProps<T>;
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/push-button.ts)

### ResistorProps `<resistor />`

```ts
export interface ResistorProps<
  PinLabel extends string = string,
> extends CommonComponentProps<PinLabel> {
  resistance: number | string;
  tolerance?: number | string;
  pullupFor?: string;
  pullupTo?: string;
  pulldownFor?: string;
  pulldownTo?: string;
  schOrientation?: SchematicOrientation;
  schSize?: SchematicSymbolSize;
  connections?: Connections<ResistorPinLabels>;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/resistor.ts)

### ResonatorProps `<resonator />`

```ts
export interface ResonatorProps extends CommonComponentProps {
  frequency: number | string;
  loadCapacitance: number | string;
  pinVariant?: ResonatorPinVariant;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/resonator.ts)

### SchematicArcProps `<schematicarc />`

```ts
export interface SchematicArcProps {
  center: Point;
  radius: Distance;
  startAngleDegrees: number | string;
  endAngleDegrees: number | string;
  direction?: "clockwise" | "counterclockwise";
  strokeWidth?: Distance;
  color?: string;
  isDashed?: boolean;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/schematic-arc.ts)

### SchematicBoxProps `<schematicbox />`

```ts
export interface SchematicBoxProps {
  name?: string;
  chipRef?: string;
  pinLabels?: PinLabelsProp;
  schPinArrangement?: SchematicPinArrangement;
  /** Per-pin schematic margin overrides keyed by pin number or label. */
  schPinStyle?: SchematicPinStyle;
  schX?: Distance;
  schY?: Distance;
  schSectionName?: string;
  schSheetName?: string;
  width?: Distance;
  height?: Distance;
  overlay?: string[];
  padding?: Distance;
  paddingLeft?: Distance;
  paddingRight?: Distance;
  paddingTop?: Distance;
  paddingBottom?: Distance;
  title?: string;
  titleAlignment?: z.infer<typeof ninePointAnchor>;
  titleColor?: string;
  titleFontSize?: Distance;
  titleInside?: boolean;
  strokeStyle?: "solid" | "dashed";
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/schematic-box.ts)

### SchematicCellProps `<schematiccell />`

```ts
export interface SchematicCellProps {
  children?: string;
  horizontalAlign?: "left" | "center" | "right";
  verticalAlign?: "top" | "middle" | "bottom";
  fontSize?: number | string;
  rowSpan?: number;
  colSpan?: number;
  width?: number | string;
  text?: string;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/schematic-cell.ts)

### SchematicCircleProps `<schematiccircle />`

```ts
export interface SchematicCircleProps {
  center: Point;
  radius: Distance;
  strokeWidth?: Distance;
  color?: string;
  isFilled?: boolean;
  fillColor?: string;
  isDashed?: boolean;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/schematic-circle.ts)

### SchematicGraphicProps `<schematicgraphic />`

```ts
export interface SchematicGraphicProps {
  /** URL or static-file import for the canonical source SVG asset. */
  imageUrl?: string;
  /**
   * Complete SVG markup, including its dimensions or viewBox. Used as the
   * source when imageUrl is omitted, or as fallback content when both exist.
   */
  svgContent?: string;
  /** Optional rendered width of the graphic. */
  width?: Distance;
  /** Optional rendered height of the graphic. */
  height?: Distance;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/schematic-graphic.ts)

### SchematicLineProps `<schematicline />`

```ts
export interface SchematicLineProps {
  x1: Distance;
  y1: Distance;
  x2: Distance;
  y2: Distance;
  strokeWidth?: Distance;
  color?: string;
  isDashed?: boolean;
  dashLength?: Distance;
  dashGap?: Distance;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/schematic-line.ts)

### SchematicPathProps `<schematicpath />`

```ts
export interface SchematicPathProps {
  points?: Point[];
  svgPath?: string;
  strokeWidth?: Distance;
  strokeColor?: string;
  dashLength?: Distance;
  dashGap?: Distance;
  isFilled?: boolean;
  fillColor?: string;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/schematic-path.ts)

### SchematicRectProps `<schematicrect />`

```ts
export interface SchematicRectProps {
  schX?: Distance;
  schY?: Distance;
  width: Distance;
  height: Distance;
  rotation?: number | string;
  strokeWidth?: Distance;
  color?: string;
  isFilled?: boolean;
  fillColor?: string;
  isDashed?: boolean;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/schematic-rect.ts)

### SchematicRowProps `<schematicrow />`

```ts
export interface SchematicRowProps {
  children?: any;
  height?: number | string;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/schematic-row.ts)

### SchematicSectionProps `<schematicsection />`

```ts
export interface SchematicSectionProps {
  displayName?: string;
  name: string;
  sectionTitleFontSize?: number | string;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/schematic-section.ts)

### SchematicSheetProps `<schematicsheet />`

```ts
export interface SchematicSheetProps {
  name?: string;
  displayName?: string;
  sheetIndex?: number;
  /** Sheet size used to render the schematic. Defaults to A4. */
  sheetSize?: SchematicSheetSize;
  /** Explicit schematic sheet width. Overrides the width from sheetSize. */
  sheetWidth?: Distance;
  /** Explicit schematic sheet height. Overrides the height from sheetSize. */
  sheetHeight?: Distance;
  children?: any;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/schematic-sheet.ts)

### SchematicSymbolProps `<schematicsymbol />`

```ts
export interface SchematicSymbolProps {
  /** Stable name for this representation, such as `A` or `B`. */
  name: string;
  /** Optional human-facing name shown in the schematic. */
  displayName?: string;
  /** Selector for the physical component represented by this symbol. */
  chipRef?: string;
  /** Name of the symbol from the schematic-symbol library. */
  symbolName: string;
  /** Maps symbol port labels to physical component port selectors. */
  connections?: Connections;
  schX?: Distance;
  schY?: Distance;
  schRotation?: number | string;
  schSectionName?: string;
  schSheetName?: string;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/schematic-symbol.ts)

### SchematicTableProps `<schematictable />`

```ts
export interface SchematicTableProps {
  schX?: number | string;
  schY?: number | string;
  children?: any;
  cellPadding?: number | string;
  borderWidth?: number | string;
  anchor?: z.infer<typeof ninePointAnchor>;
  fontSize?: number | string;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/schematic-table.ts)

### SchematicTextProps `<schematictext />`

```ts
export interface SchematicTextProps {
  schX?: Distance;
  schY?: Distance;
  text: string;
  fontSize?: number;
  anchor?: z.infer<typeof fivePointAnchor> | z.infer<typeof ninePointAnchor>;
  color?: string;
  schRotation?: number | string;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/schematic-text.ts)

### SilkscreenCircleProps `<silkscreencircle />`

```ts
export type SilkscreenCircleProps = z.input<typeof silkscreenCircleProps>;
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/silkscreen-circle.ts)

### SilkscreenGraphicProps `<silkscreengraphic />`

```ts
export interface SilkscreenGraphicProps {
  /**
   * URL or static-file import for the source image. tscircuit/core converts the
   * image into the pcb_silkscreen_graphic BRep in circuit-json.
   */
  imageUrl: string;
  /** Width of the rendered silkscreen graphic on the PCB. */
  width: Distance;
  /** Height of the rendered silkscreen graphic on the PCB. */
  height: Distance;
  /** PCB layer for the silkscreen graphic. */
  layer?: VisibleLayer;
  pcbX?: string | number;
  pcbY?: string | number;
  pcbLeftEdgeX?: string | number;
  pcbRightEdgeX?: string | number;
  pcbTopEdgeY?: string | number;
  pcbBottomEdgeY?: string | number;
  pcbOffsetX?: string | number;
  pcbOffsetY?: string | number;
  pcbRotation?: string | number;
  pcbPositionAnchor?: string;
  pcbPositionMode?:
    | "relative_to_group_anchor"
    | "auto"
    | "relative_to_board_anchor"
    | "relative_to_component_anchor";
  shouldBeOnEdgeOfBoard?: boolean;
  pcbMarginTop?: string | number;
  pcbMarginRight?: string | number;
  pcbMarginBottom?: string | number;
  pcbMarginLeft?: string | number;
  pcbMarginX?: string | number;
  pcbMarginY?: string | number;
  pcbRelative?: boolean;
  relative?: boolean;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/silkscreen-graphic.ts)

### SilkscreenLineProps `<silkscreenline />`

```ts
export type SilkscreenLineProps = z.input<typeof silkscreenLineProps>;
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/silkscreen-line.ts)

### SilkscreenPathProps `<silkscreenpath />`

```ts
export type SilkscreenPathProps = z.input<typeof silkscreenPathProps>;
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/silkscreen-path.ts)

### SilkscreenRectProps `<silkscreenrect />`

```ts
export type SilkscreenRectProps = z.input<typeof silkscreenRectProps>;
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/silkscreen-rect.ts)

### SilkscreenTextProps `<silkscreentext />`

```ts
export type SilkscreenTextProps = z.input<typeof silkscreenTextProps>;
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/silkscreen-text.ts)

### RectSmtPadProps `<smtpad />`

```ts
export interface RectSmtPadProps extends Omit<PcbLayoutProps, "pcbRotation"> {
  name?: string;
  shape: "rect";
  width: Distance;
  height: Distance;
  rectBorderRadius?: Distance;
  cornerRadius?: Distance;
  portHints?: PortHints;
  coveredWithSolderMask?: boolean;
  solderMaskMargin?: Distance;
  solderMaskMarginLeft?: Distance;
  solderMaskMarginRight?: Distance;
  solderMaskMarginTop?: Distance;
  solderMaskMarginBottom?: Distance;
  solderPasteMargin?: Distance;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/smtpad.ts)

### SolderJumperProps `<solderjumper />`

```ts
export interface SolderJumperProps extends JumperProps {
  /**
   * Pins that are bridged with solder by default
   */
  bridgedPins?: string[][];
  /**
   * If true, all pins are connected with cuttable traces
   */
  bridged?: boolean;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/solderjumper.ts)

### RectSolderPasteProps `<solderpaste />`

```ts
export interface RectSolderPasteProps extends Omit<
  PcbLayoutProps,
  "pcbRotation"
> {
  shape: "rect";
  width: Distance;
  height: Distance;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/solderpaste.ts)

### SpiceModelProps `<spicemodel />`

```ts
export interface SpiceModelProps {
  source: string;
  spicePinMapping?: Record<string, string>;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/spicemodel.ts)

### StampboardProps `<stampboard />`

```ts
export interface StampboardProps extends BoardProps {
  leftPinCount?: number;
  rightPinCount?: number;
  topPinCount?: number;
  bottomPinCount?: number;
  leftPins?: string[];
  rightPins?: string[];
  topPins?: string[];
  bottomPins?: string[];
  pinPitch?: number | string;
  innerHoles?: boolean;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/stampboard.ts)

### SubcircuitProps `<subcircuit />`

```ts
export type SubcircuitProps = SubcircuitGroupProps;
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/subcircuit.ts)

### SwitchProps `<switch />`

```ts
export interface SwitchProps extends CommonComponentProps {
  type?: "spst" | "spdt" | "dpst" | "dpdt";
  pinLabels?: PinLabelsProp<SchematicPinLabel>;
  /**
   * Pin names or aliases intentionally left unconnected. Accepts mutable or
   * readonly arrays, using the same label validation as chip noConnect.
   * Omitted or empty arrays mark no pins. Parsed labels are preserved and
   * matching source ports get do_not_connect; explicit connections are not removed.
   */
  noConnect?: readonly SchematicPinLabel[] | SchematicPinLabel[];
  isNormallyClosed?: boolean;
  spdt?: boolean;
  spst?: boolean;
  dpst?: boolean;
  dpdt?: boolean;
  simSwitchFrequency?: number | string;
  simCloseAt?: number | string;
  simOpenAt?: number | string;
  simStartClosed?: boolean;
  simStartOpen?: boolean;
  connections?: Connections<string>;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/switch.ts)

### SymbolProps `<symbol />`

```ts
export interface SymbolProps {
  /**
   * The facing direction that the symbol is designed for. If you set this to "right",
   * then it means the children were intended to represent the symbol facing right.
   * Generally, you shouldn't set this except where it can help prevent confusion
   * because you have a complex symbol. Default is "right" and this is most intuitive.
   */
  originalFacingDirection?: "up" | "down" | "left" | "right";
  width?: string | number;
  height?: string | number;
  name?: string;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/symbol.ts)

### TestpointProps `<testpoint />`

```ts
export interface TestpointProps extends CommonComponentProps {
  /**
   * The footprint variant of the testpoint either a surface pad or through-hole
   */
  footprintVariant?: "pad" | "through_hole";
  /**
   * The shape of the pad if using a pad variant
   */
  padShape?: "rect" | "circle";
  /**
   * Diameter of the copper pad (applies to both SMD pads and plated holes)
   */
  padDiameter?: number | string;
  /**
   * Diameter of the hole if using a through-hole testpoint
   */
  holeDiameter?: number | string;
  /**
   * Width of the pad when padShape is rect
   */
  width?: number | string;
  /**
   * Height of the pad when padShape is rect
   */
  height?: number | string;
  connections?: TestpointConnections;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/testpoint.ts)

### ToolingrailProps `<toolingrail />`

```ts
export interface ToolingrailProps {
  children?: any;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/toolingrail.ts)

### TraceProps `<trace />`

```ts
export type TraceProps = z.input<typeof traceProps>;
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/trace.ts)

### TraceHintProps `<tracehint />`

```ts
export type TraceHintProps = z.input<typeof traceHintProps>;
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/trace-hint.ts)

### TransistorProps `<transistor />`

```ts
export interface TransistorProps<
  PinLabel extends string = string,
> extends CommonComponentProps<PinLabel> {
  type: "npn" | "pnp" | "bjt" | "jfet" | "mosfet" | "igbt";
  connections?: Connections<transistorPinsLabels>;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/transistor.ts)

### ViaProps `<via />`

```ts
export interface ViaProps extends CommonLayoutProps {
  name?: string;
  fromLayer?: LayerRefInput;
  toLayer?: LayerRefInput;
  layers?: LayerRefInput[];
  holeDiameter?: number | string;
  outerDiameter?: number | string;
  connectsTo?: string | string[];
  netIsAssignable?: boolean;
  tented?:
    | boolean
    | "both_sides"
    | "top_and_bottom_tented"
    | "top_tented"
    | "bottom_tented"
    | "exposed";
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/via.ts)

### VoltageProbeProps `<voltageprobe />`

```ts
export interface VoltageProbeProps extends Omit<CommonComponentProps, "name"> {
  name?: string;
  connectsTo: string;
  referenceTo?: string;
  color?: string;
  graphDisplayName?: string;
  graphCenter?: number;
  graphVerticalOffset?: number | string;
  graphVoltagePerDiv?: number | string;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/voltageprobe.ts)

### VoltageSourceProps `<voltagesource />`

```ts
export interface VoltageSourceProps<
  PinLabel extends string = string,
> extends CommonComponentProps<PinLabel> {
  voltage?: number | string;
  frequency?: number | string;
  peakToPeakVoltage?: number | string;
  waveShape?: WaveShape;
  phase?: number | string;
  dutyCycle?: number | string;
  pulseDelay?: number | string;
  riseTime?: number | string;
  fallTime?: number | string;
  pulseWidth?: number | string;
  period?: number | string;
  /** Small-signal AC magnitude. Raw numbers are volts. */
  acMagnitude?: number | string;
  /** Small-signal AC phase. Raw numbers are degrees. */
  acPhase?: number | string;
  connections?: Connections<VoltageSourcePinLabels>;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/components/voltagesource.ts)

<!-- INTERFACE_DEFINITIONS_END -->

<!-- PLATFORM_CONFIG_START -->

## tscircuit Platform Configuration

### PlatformConfig

```ts
export interface PlatformConfig {
  partsEngine?: PartsEngine;

  /** Optional fabricator-specific DRC provider. No checks run when omitted. */
  fabricatorEngine?: FabricatorEngine;

  autorouter?: AutorouterProp;

  autorouterMap?: Record<string, AutorouterDefinition>;

  /** Use networked Pipeline9 node solving at effort 1. Omitted or false keeps local routing.
   * Explicit alternative pipelines and effort levels retain their local solver.
   */
  useCloudAutorouter?: boolean;

  /**
   * Allows the deprecated sequential_trace and auto_cloud autorouter presets.
   * Defaults to false because these presets are otherwise disabled.
   * This also applies to the sequential-trace and auto-cloud aliases.
   * Platforms should only enable this temporarily while migrating projects.
   * For sequential_trace / sequential-trace, use the default autorouter with
   * <autoroutingphase /> or <fanout /> elements as needed instead.
   */
  allowLegacyAutorouters?: boolean;

  /** A localStorage-compatible cache used by render phases and engines. */
  localCacheEngine?: LocalCacheEngine;

  /**
   * Analyze rendered and supplier footprints so manufacturing exporters can
   * align their semantic pin 1 orientations.
   */
  enablePartOrientationAnalysis?: boolean;

  /**
   * Maximum time, in milliseconds, that an individual PCB pack solver may run.
   * The timeout is checked between solver steps.
   */
  pcbPackSolverTimeoutMs?: number;

  registryApiUrl?: string;

  cloudAutorouterUrl?: string;

  projectName?: string;
  projectBaseUrl?: string;
  version?: string;
  url?: string;
  printBoardInformationToSilkscreen?: boolean;
  includeBoardFiles?: string[];
  snapshotsDir?: string;

  defaultSpiceEngine?: AutocompleteString<"spicey" | "ngspice">;

  unitPreference?: "mm" | "in" | "mil";

  pcbDisabled?: boolean;
  routingDisabled?: boolean;
  schematicDisabled?: boolean;
  partsEngineDisabled?: boolean;
  /**
   * Disables analog simulation model processing and simulator execution.
   * Defaults to false.
   */
  analogSimulationDisabled?: boolean;
  drcChecksDisabled?: boolean;
  netlistDrcChecksDisabled?: boolean;
  routingDrcChecksDisabled?: boolean;
  placementDrcChecksDisabled?: boolean;
  pinSpecificationDrcChecksDisabled?: boolean;

  spiceEngineMap?: Record<string, SpiceEngine>;

  footprintLibraryMap?: Record<
    FootprintLibraryPrefix,
    | ((
        path: string,
        options?: { resolvedPcbStyle?: PcbStyle },
      ) => Promise<FootprintLibraryResult>)
    | Record<
        string,
        | any[]
        | ((
            path: string,
            options?: { resolvedPcbStyle?: PcbStyle },
          ) => Promise<FootprintLibraryResult>)
      >
  >;

  footprintFileParserMap?: Record<FileExtension, FootprintFileParserEntry>;

  staticFileLoaderMap?: Record<
    FileExtension,
    (fileContent: FileContent) => Promise<EsModuleImportResult>
  >;

  resolveProjectStaticFileImportUrl?: (path: string) => Promise<string>;
  nodeModulesResolver?: (modulePath: string) => Promise<string | null>;
  platformFetch?: typeof fetch;
}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/platformConfig.ts)
<!-- PLATFORM_CONFIG_END -->

<!-- PROJECT_CONFIG_START -->

## tscircuit Project Configuration

### ProjectConfig

```ts
export interface ProjectConfig extends Pick<
  PlatformConfig,
  | "projectName"
  | "projectBaseUrl"
  | "version"
  | "url"
  | "printBoardInformationToSilkscreen"
  | "includeBoardFiles"
  | "snapshotsDir"
  | "defaultSpiceEngine"
  | "pcbDisabled"
  | "schematicDisabled"
  | "analogSimulationDisabled"
> {}
```

[Source](https://github.com/tscircuit/props/blob/main/lib/projectConfig.ts)
<!-- PROJECT_CONFIG_END -->
