import { expect, test } from "bun:test"

test("comment reporting uses trusted workflow code on a different runner from PR execution", async () => {
  const workflow = Bun.YAML.parse(
    await Bun.file(
      new URL("../.github/workflows/benchmark.yml", import.meta.url),
    ).text(),
  ) as any
  expect(workflow.on.issue_comment.types).toEqual(["created"])
  expect(workflow.on.workflow_dispatch.inputs.pr_number.description).toContain(
    "open or merged PR",
  )
  expect(workflow.permissions).toEqual({})
  const { prepare, benchmark, report } = workflow.jobs
  expect(benchmark["runs-on"]).toBe("blacksmith-32vcpu-ubuntu-2404-arm")
  expect(benchmark.permissions).toEqual({ contents: "read" })
  expect(prepare.permissions["pull-requests"]).toBe("write")
  expect(report.permissions["pull-requests"]).toBe("write")
  expect(report.permissions.issues).toBe("write")
  expect(report.needs).toEqual(["prepare", "benchmark"])
  expect(report.if).toContain("always()")
  for (const job of [prepare, report]) {
    const checkout = job.steps.find(
      (step: any) => step.uses === "actions/checkout@v4",
    )
    expect(checkout.with.ref).toBe("${{ github.workflow_sha }}")
    expect(checkout.with["persist-credentials"]).toBe(false)
  }
  const checkout = benchmark.steps.find(
    (step: any) => step.uses === "actions/checkout@v4",
  )
  expect(checkout.with.ref).toBe("${{ needs.prepare.outputs.ref }}")
  expect(checkout.with["persist-credentials"]).toBe(false)
  const command = benchmark.steps.find(
    (step: any) => step.name === "Run all dataset 31 samples",
  ).run
  expect(command).toContain("./benchmark.sh")
  expect(command).toContain("--dataset dataset31")
  expect(command).not.toMatch(/--limit|--sample /)
  const packageJson = await Bun.file(
    new URL("../package.json", import.meta.url),
  ).json()
  expect(
    Object.keys(packageJson.scripts).filter((name) =>
      name.startsWith("benchmark"),
    ),
  ).toEqual(["benchmark"])
  for (const name of ["srj29-benchmark.yml", "benchmark-testbox.yml"])
    expect(
      await Bun.file(
        new URL(`../.github/workflows/${name}`, import.meta.url),
      ).exists(),
    ).toBe(false)
  expect(JSON.stringify(benchmark)).not.toContain("secrets.")
})
