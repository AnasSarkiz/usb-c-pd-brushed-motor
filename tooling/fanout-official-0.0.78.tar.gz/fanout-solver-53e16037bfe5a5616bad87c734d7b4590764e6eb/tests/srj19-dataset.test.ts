import { expect, test } from "bun:test"
import { FanoutSolver } from "lib/fanout-solver"
import {
  createSrj19FanoutInput,
  SRJ19_FANOUT_LAYER_COUNT,
  srj19FanoutSamples,
} from "../datasets/srj19"

test("SRJ19 adapts a representative sample into a BGA fanout problem", () => {
  expect(srj19FanoutSamples).toHaveLength(200)
  const sample = srj19FanoutSamples[0]!
  expect(sample.fanoutConnectionCount).toBeGreaterThan(0)
  expect(sample.fanoutConnectionCount).toBeLessThan(
    sample.sourceConnectionCount,
  )
  expect(sample.simpleRouteJson.connections).toHaveLength(
    sample.fanoutConnectionCount,
  )
  expect(sample.simpleRouteJson.obstacles).toHaveLength(sample.obstacleCount)
  expect(sample.simpleRouteJson.buses).toBeUndefined()
  expect(sample.simpleRouteJson.layerCount).toBe(SRJ19_FANOUT_LAYER_COUNT)
  expect(SRJ19_FANOUT_LAYER_COUNT).toBe(6)
  expect(sample.solverOptions.sourceComponentId).toBe("bga_component")
  expect(sample.solverOptions.sharedBoundary).toEqual(
    sample.simpleRouteJson.bounds,
  )

  const solver = new FanoutSolver(sample.simpleRouteJson, {
    ...sample.solverOptions,
    maxLayerCombinations: 1,
  })
  expect(solver.preparedBuses).toHaveLength(sample.fanoutConnectionCount)
  expect(
    solver.preparedBuses.every((bus) => bus.componentId === "bga_component"),
  ).toBe(true)
})

test("SRJ19 keeps all obstacles and only connections touching the BGA", () => {
  const sample = srj19FanoutSamples[0]!
  const adaptedAgain = createSrj19FanoutInput(sample.simpleRouteJson)

  expect(adaptedAgain.obstacles).toBe(sample.simpleRouteJson.obstacles)
  expect(adaptedAgain.connections).toHaveLength(sample.fanoutConnectionCount)
})
