/** Trusted automation: import this from the workflow revision, never the PR checkout. */
export const isBenchmarkComment = (payload) =>
  Boolean(payload.issue?.pull_request) &&
  payload.comment?.user?.type !== "Bot" &&
  payload.comment?.body?.trim() === "/benchmark"

export async function preparePrBenchmark({ github, context, core }) {
  core.setOutput("enabled", "false")
  if (
    context.eventName !== "workflow_dispatch" &&
    !isBenchmarkComment(context.payload)
  )
    return
  // Check current access rather than trusting a comment's cached association.
  const username =
    context.eventName === "issue_comment"
      ? context.payload.comment.user.login
      : context.actor
  let permission
  try {
    permission = (
      await github.rest.repos.getCollaboratorPermissionLevel({
        ...context.repo,
        username,
      })
    ).data.permission
  } catch (error) {
    if (error.status !== 404) throw error
  }
  if (!["admin", "maintain", "write"].includes(permission)) {
    core.notice("Only repository writers can request a benchmark")
    return
  }
  const rawNumber =
    context.eventName === "issue_comment"
      ? String(context.issue.number)
      : (context.payload.inputs?.pr_number ?? "").trim()
  if (
    rawNumber &&
    (!/^[1-9]\d*$/.test(rawNumber) || !Number.isSafeInteger(Number(rawNumber)))
  )
    throw new Error("pr_number must be a positive integer")
  let repository = `${context.repo.owner}/${context.repo.repo}`
  let ref = context.sha
  let commentId = ""
  let target = "workflow ref"
  const runUrl = `${context.serverUrl}/${repository}/actions/runs/${context.runId}`
  if (rawNumber) {
    const pr = (
      await github.rest.pulls.get({
        ...context.repo,
        pull_number: Number(rawNumber),
      })
    ).data
    if (pr.state === "open") {
      if (!pr.head.repo || !/^[a-f0-9]{40}$/.test(pr.head.sha))
        throw new Error("PR head is unavailable")
      ref = pr.head.sha
      repository = pr.head.repo.full_name
      target = "PR head"
    } else if (pr.merged_at) {
      if (!/^[a-f0-9]{40}$/.test(pr.merge_commit_sha))
        throw new Error("Merged PR commit is unavailable")
      ref = pr.merge_commit_sha
      target = "merged commit"
    } else {
      throw new Error(
        "Benchmark requests require an open or merged pull request",
      )
    }
    const comment = await github.rest.issues.createComment({
      ...context.repo,
      issue_number: Number(rawNumber),
      body: `## Dataset 31 — AM62L, RK3308, K230, i.MX6ULL, T113-S3, and AM3352 fanout benchmark\n\nQueued ${target} \`${ref.slice(0, 7)}\` on Blacksmith. All 72 dataset-fanout31-am62l samples (12 AM62L, 12 RK3308, 12 K230, 12 i.MX6ULL, 12 T113-S3, and 12 AM3352) will run, with a per-sample deadline.\n\n[View run](${runUrl})`,
    })
    commentId = String(comment.data.id)
  }
  core.setOutput("ref", ref)
  core.setOutput("repository", repository)
  core.setOutput("comment_id", commentId)
  core.setOutput("enabled", "true")
}

const escape = (value) =>
  String(value)
    .slice(0, 120)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll("|", "&#124;")
    .replaceAll("@", "&#64;")
    .replaceAll("`", "&#96;")
    .replace(/[\r\n]/g, " ")
const finite = (value) =>
  typeof value === "number" && Number.isFinite(value) && value >= 0

/** Render data only; never execute scripts or post raw Markdown supplied by the PR. */
export function renderBenchmarkComment(report, { ref, runUrl, result }) {
  const header = [
    "## Dataset 31 — AM62L, RK3308, K230, i.MX6ULL, T113-S3, and AM3352 fanout benchmark",
    "",
    `Commit: \`${ref.slice(0, 7)}\`. Blacksmith job: **${result}**.`,
    "",
    `[Full JSON/Markdown reports and logs](${runUrl})`,
    "",
  ]
  if (!report)
    return [
      ...header,
      "No readable dataset 31 benchmark report was produced. See the run logs for the failure.",
    ].join("\n")
  if (
    report.version !== 2 ||
    report.dataset !== "dataset31" ||
    !Array.isArray(report.rows) ||
    report.rows.length > 10000 ||
    !finite(report.totalSamples) ||
    report.totalSamples < report.rows.length
  )
    throw new Error("Invalid benchmark report")
  const keys = new Set()
  for (const row of report.rows) {
    if (
      row.dataset !== "dataset31" ||
      typeof row.sample !== "string" ||
      !["solved", "partial", "error", "timeout"].includes(row.status) ||
      !finite(row.connections) ||
      !finite(row.routed) ||
      row.routed > row.connections ||
      !finite(row.milliseconds)
    )
      throw new Error("Invalid benchmark row")
    const key = JSON.stringify([row.dataset, row.sample])
    if (keys.has(key)) throw new Error("Duplicate benchmark row")
    keys.add(key)
  }
  const { rows } = report
  const count = (group, status) =>
    group.filter((row) => row.status === status).length
  header.push(
    `**Solved ${count(rows, "solved")}/${report.totalSamples} selected samples.** Completed ${rows.length}/${report.totalSamples}; partial ${count(rows, "partial")}; errors ${count(rows, "error")}; timeouts ${count(rows, "timeout")}.`,
    "",
  )
  if (rows.length !== report.totalSamples)
    header.push(
      "⚠️ Incomplete run: unreported samples are not counted as solved.",
      "",
    )
  const config = report.configuration
  if (
    config &&
    finite(config.concurrency) &&
    finite(config.sampleTimeoutSeconds)
  )
    header.push(
      `Concurrency: ${config.concurrency}; per-sample deadline: ${config.sampleTimeoutSeconds}s; assignment budget: ${finite(config.maxLayerCombinations) ? config.maxLayerCombinations : "sample defaults"}.`,
      "",
    )
  header.push(
    "Only dataset-fanout31-am62l is benchmarked: 12 AM62L, 12 RK3308, 12 K230, 12 i.MX6ULL, 12 T113-S3, and 12 AM3352 cases. A case is solved only when all its SoC connections have validated fanout with the original constraints (135 for AM62L; 162 for RK3308; 171 for K230; 102 for i.MX6ULL; 128 for T113-S3; 322 for AM3352). RAM fanout and inter-chip routing are separate phases.",
  )
  if (
    report.datasetSource &&
    /^[a-f0-9]{40}$/.test(report.datasetSource.commit)
  )
    header.push(
      "",
      `Dataset revision: \`${report.datasetSource.commit.slice(0, 7)}\`.`,
    )
  header.push(
    "",
    "<details><summary>Per-sample results</summary>",
    "",
    "| Sample | Status | Routed | Seconds |",
    "| --- | --- | ---: | ---: |",
  )
  let length = header.join("\n").length
  for (const [index, row] of rows.entries()) {
    const line = `| ${escape(row.sample)} | ${row.status} | ${row.routed}/${row.connections} | ${(row.milliseconds / 1000).toFixed(2)} |`
    if (length + line.length > 55000) {
      header.push(
        "",
        `${rows.length - index} additional rows are available in the full report artifact.`,
      )
      break
    }
    header.push(line)
    length += line.length + 1
  }
  header.push("", "</details>")
  return header.join("\n")
}
