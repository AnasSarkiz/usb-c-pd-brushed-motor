import type { Obstacle } from "@tscircuit/capacity-autorouter"
import {
  applyToPoint,
  compose,
  rotateDEG,
  translate,
} from "transformation-matrix"
import type { Bounds } from "./types"

type ShapeAwareObstacle = Obstacle & {
  shape?: "circle"
  ccwRotationDegrees?: number
}

/** World-space bounds for the actual pad geometry, including rotation. */
export function getObstacleAxisAlignedBounds(
  obstacle: ShapeAwareObstacle,
): Bounds & { xRadius: number } {
  if (obstacle.shape === "circle") {
    const radius = obstacle.width / 2
    return {
      minX: obstacle.center.x - radius,
      maxX: obstacle.center.x + radius,
      minY: obstacle.center.y - radius,
      maxY: obstacle.center.y + radius,
      xRadius: radius,
    }
  }

  const halfWidth = obstacle.width / 2
  const halfHeight = obstacle.height / 2
  const obstacleToWorldTransform = compose(
    translate(obstacle.center.x, obstacle.center.y),
    rotateDEG(obstacle.ccwRotationDegrees ?? 0),
  )
  const corners = [
    { x: -halfWidth, y: -halfHeight },
    { x: halfWidth, y: -halfHeight },
    { x: halfWidth, y: halfHeight },
    { x: -halfWidth, y: halfHeight },
  ].map((corner) => applyToPoint(obstacleToWorldTransform, corner))
  const minX = Math.min(...corners.map((corner) => corner.x))
  const maxX = Math.max(...corners.map((corner) => corner.x))
  return {
    minX,
    maxX,
    minY: Math.min(...corners.map((corner) => corner.y)),
    maxY: Math.max(...corners.map((corner) => corner.y)),
    xRadius: (maxX - minX) / 2,
  }
}
